﻿namespace Vaild_Class
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnVaildate = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.edtClass = new System.Windows.Forms.TextBox();
			this.lblVaild = new System.Windows.Forms.Label();
			this.rbtnName1 = new System.Windows.Forms.RadioButton();
			this.rbtnName2 = new System.Windows.Forms.RadioButton();
			this.rbtnName3 = new System.Windows.Forms.RadioButton();
			this.SuspendLayout();
			// 
			// btnVaildate
			// 
			this.btnVaildate.Location = new System.Drawing.Point(576, 258);
			this.btnVaildate.Name = "btnVaildate";
			this.btnVaildate.Size = new System.Drawing.Size(148, 77);
			this.btnVaildate.TabIndex = 0;
			this.btnVaildate.Text = "Vaildate";
			this.btnVaildate.UseVisualStyleBackColor = true;
			this.btnVaildate.Click += new System.EventHandler(this.button1_Click);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(324, 197);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(152, 17);
			this.label1.TabIndex = 1;
			this.label1.Text = "Please enter the class:";
			// 
			// edtClass
			// 
			this.edtClass.Location = new System.Drawing.Point(495, 194);
			this.edtClass.Name = "edtClass";
			this.edtClass.Size = new System.Drawing.Size(313, 22);
			this.edtClass.TabIndex = 2;
			// 
			// lblVaild
			// 
			this.lblVaild.AutoSize = true;
			this.lblVaild.Location = new System.Drawing.Point(608, 134);
			this.lblVaild.Name = "lblVaild";
			this.lblVaild.Size = new System.Drawing.Size(0, 17);
			this.lblVaild.TabIndex = 3;
			// 
			// rbtnName1
			// 
			this.rbtnName1.AutoSize = true;
			this.rbtnName1.Location = new System.Drawing.Point(883, 162);
			this.rbtnName1.Name = "rbtnName1";
			this.rbtnName1.Size = new System.Drawing.Size(81, 21);
			this.rbtnName1.TabIndex = 4;
			this.rbtnName1.TabStop = true;
			this.rbtnName1.Text = "Gethrod";
			this.rbtnName1.UseVisualStyleBackColor = true;
			this.rbtnName1.Visible = false;
			// 
			// rbtnName2
			// 
			this.rbtnName2.AutoSize = true;
			this.rbtnName2.Location = new System.Drawing.Point(883, 184);
			this.rbtnName2.Name = "rbtnName2";
			this.rbtnName2.Size = new System.Drawing.Size(86, 21);
			this.rbtnName2.TabIndex = 5;
			this.rbtnName2.TabStop = true;
			this.rbtnName2.Text = "Azamarr ";
			this.rbtnName2.UseVisualStyleBackColor = true;
			this.rbtnName2.Visible = false;
			// 
			// rbtnName3
			// 
			this.rbtnName3.AutoSize = true;
			this.rbtnName3.Location = new System.Drawing.Point(883, 206);
			this.rbtnName3.Name = "rbtnName3";
			this.rbtnName3.Size = new System.Drawing.Size(70, 21);
			this.rbtnName3.TabIndex = 6;
			this.rbtnName3.TabStop = true;
			this.rbtnName3.Text = "Hodus";
			this.rbtnName3.UseVisualStyleBackColor = true;
			this.rbtnName3.Visible = false;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1276, 549);
			this.Controls.Add(this.rbtnName3);
			this.Controls.Add(this.rbtnName2);
			this.Controls.Add(this.rbtnName1);
			this.Controls.Add(this.lblVaild);
			this.Controls.Add(this.edtClass);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.btnVaildate);
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnVaildate;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox edtClass;
		private System.Windows.Forms.Label lblVaild;
		private System.Windows.Forms.RadioButton rbtnName1;
		private System.Windows.Forms.RadioButton rbtnName2;
		private System.Windows.Forms.RadioButton rbtnName3;
	}
}

