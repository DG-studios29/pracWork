﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Vaild_Class
{
	public partial class Form1 : Form
	{
		String[] sClass = { "Barbarian", "Fighter", "Paladin", "Bard", "Sorcerer", "Warlock", "Cleric", "Druid", "Monk", "Ranger", "Rogue", "Wizard"};
		
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			string sInput = edtClass.Text;
			bool isvaild = false;

			for (int i = 0; i < sClass.Length; ++i)
			{
				if (sInput == sClass[i])
				{
					isvaild = true;
					break;
				}
			}
			if (isvaild)
			{ lblVaild.Text = "The class is vaild";
				rbtnName1.Visible = true;
				rbtnName2.Visible = true;
				rbtnName3.Visible = true;
			}
			else
			{
				lblVaild.Text = "The class is invaild";
			}
		}
	}

    /*

		
Lydan
Syrin
Ptorik
Joz
Varog

Hezra
Feron
Ophni
Colborn
Fintis
Gatlin
Jinto
Hagalbar
Krinn
Lenox
Revvyn

Dimian
Paskel
Kontas
Weston

Jather 
Tekren 
Jareth
Adon

 

 

 

	*/
}
