﻿namespace Chess
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.btnShow = new System.Windows.Forms.Button();
			this.lblQuestion = new System.Windows.Forms.Label();
			this.KnightW = new System.Windows.Forms.PictureBox();
			this.edtrich = new System.Windows.Forms.RichTextBox();
			this.cbChessPiece = new System.Windows.Forms.ComboBox();
			this.CastleB = new System.Windows.Forms.PictureBox();
			this.QueenB = new System.Windows.Forms.PictureBox();
			this.QueenW = new System.Windows.Forms.PictureBox();
			this.BishopB = new System.Windows.Forms.PictureBox();
			this.BishopW = new System.Windows.Forms.PictureBox();
			this.KnightB = new System.Windows.Forms.PictureBox();
			this.CastleW = new System.Windows.Forms.PictureBox();
			this.KingB = new System.Windows.Forms.PictureBox();
			this.KingW = new System.Windows.Forms.PictureBox();
			this.PawnB = new System.Windows.Forms.PictureBox();
			this.PawnW = new System.Windows.Forms.PictureBox();
			this.label1 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.KnightW)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.CastleB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.QueenB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.QueenW)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.BishopB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.BishopW)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.KnightB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.CastleW)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.KingB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.KingW)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PawnB)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.PawnW)).BeginInit();
			this.SuspendLayout();
			// 
			// btnShow
			// 
			this.btnShow.Location = new System.Drawing.Point(535, 89);
			this.btnShow.Name = "btnShow";
			this.btnShow.Size = new System.Drawing.Size(98, 26);
			this.btnShow.TabIndex = 0;
			this.btnShow.Text = "Show";
			this.btnShow.UseVisualStyleBackColor = true;
			this.btnShow.Click += new System.EventHandler(this.btnShow_Click);
			// 
			// lblQuestion
			// 
			this.lblQuestion.AutoSize = true;
			this.lblQuestion.Location = new System.Drawing.Point(44, 92);
			this.lblQuestion.Name = "lblQuestion";
			this.lblQuestion.Size = new System.Drawing.Size(263, 17);
			this.lblQuestion.TabIndex = 1;
			this.lblQuestion.Text = "What piece would you like to learn about";
			// 
			// KnightW
			// 
			this.KnightW.ErrorImage = null;
			this.KnightW.Image = ((System.Drawing.Image)(resources.GetObject("KnightW.Image")));
			this.KnightW.InitialImage = null;
			this.KnightW.Location = new System.Drawing.Point(252, 181);
			this.KnightW.Name = "KnightW";
			this.KnightW.Size = new System.Drawing.Size(152, 214);
			this.KnightW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.KnightW.TabIndex = 2;
			this.KnightW.TabStop = false;
			this.KnightW.Visible = false;
			// 
			// edtrich
			// 
			this.edtrich.Location = new System.Drawing.Point(754, 138);
			this.edtrich.Name = "edtrich";
			this.edtrich.Size = new System.Drawing.Size(446, 401);
			this.edtrich.TabIndex = 3;
			this.edtrich.Text = "";
			// 
			// cbChessPiece
			// 
			this.cbChessPiece.FormattingEnabled = true;
			this.cbChessPiece.Items.AddRange(new object[] {
            "King",
            "Queen",
            "Bishop",
            "Knight",
            "Castle",
            "Pawn"});
			this.cbChessPiece.Location = new System.Drawing.Point(313, 89);
			this.cbChessPiece.Name = "cbChessPiece";
			this.cbChessPiece.Size = new System.Drawing.Size(198, 24);
			this.cbChessPiece.TabIndex = 4;
			// 
			// CastleB
			// 
			this.CastleB.ErrorImage = null;
			this.CastleB.Image = ((System.Drawing.Image)(resources.GetObject("CastleB.Image")));
			this.CastleB.InitialImage = null;
			this.CastleB.Location = new System.Drawing.Point(429, 180);
			this.CastleB.Name = "CastleB";
			this.CastleB.Size = new System.Drawing.Size(167, 190);
			this.CastleB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.CastleB.TabIndex = 5;
			this.CastleB.TabStop = false;
			this.CastleB.Visible = false;
			// 
			// QueenB
			// 
			this.QueenB.ErrorImage = null;
			this.QueenB.Image = ((System.Drawing.Image)(resources.GetObject("QueenB.Image")));
			this.QueenB.InitialImage = null;
			this.QueenB.Location = new System.Drawing.Point(488, 181);
			this.QueenB.Name = "QueenB";
			this.QueenB.Size = new System.Drawing.Size(108, 236);
			this.QueenB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.QueenB.TabIndex = 7;
			this.QueenB.TabStop = false;
			this.QueenB.Visible = false;
			// 
			// QueenW
			// 
			this.QueenW.ErrorImage = null;
			this.QueenW.Image = ((System.Drawing.Image)(resources.GetObject("QueenW.Image")));
			this.QueenW.InitialImage = null;
			this.QueenW.Location = new System.Drawing.Point(233, 181);
			this.QueenW.Name = "QueenW";
			this.QueenW.Size = new System.Drawing.Size(119, 251);
			this.QueenW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.QueenW.TabIndex = 6;
			this.QueenW.TabStop = false;
			this.QueenW.Visible = false;
			// 
			// BishopB
			// 
			this.BishopB.ErrorImage = null;
			this.BishopB.Image = ((System.Drawing.Image)(resources.GetObject("BishopB.Image")));
			this.BishopB.InitialImage = null;
			this.BishopB.Location = new System.Drawing.Point(459, 181);
			this.BishopB.Name = "BishopB";
			this.BishopB.Size = new System.Drawing.Size(138, 210);
			this.BishopB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.BishopB.TabIndex = 9;
			this.BishopB.TabStop = false;
			this.BishopB.Visible = false;
			// 
			// BishopW
			// 
			this.BishopW.ErrorImage = null;
			this.BishopW.Image = ((System.Drawing.Image)(resources.GetObject("BishopW.Image")));
			this.BishopW.InitialImage = null;
			this.BishopW.Location = new System.Drawing.Point(233, 180);
			this.BishopW.Name = "BishopW";
			this.BishopW.Size = new System.Drawing.Size(128, 211);
			this.BishopW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.BishopW.TabIndex = 8;
			this.BishopW.TabStop = false;
			this.BishopW.Visible = false;
			// 
			// KnightB
			// 
			this.KnightB.ErrorImage = null;
			this.KnightB.Image = ((System.Drawing.Image)(resources.GetObject("KnightB.Image")));
			this.KnightB.InitialImage = null;
			this.KnightB.Location = new System.Drawing.Point(429, 181);
			this.KnightB.Name = "KnightB";
			this.KnightB.Size = new System.Drawing.Size(169, 212);
			this.KnightB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.KnightB.TabIndex = 11;
			this.KnightB.TabStop = false;
			this.KnightB.Visible = false;
			// 
			// CastleW
			// 
			this.CastleW.ErrorImage = null;
			this.CastleW.Image = ((System.Drawing.Image)(resources.GetObject("CastleW.Image")));
			this.CastleW.InitialImage = null;
			this.CastleW.Location = new System.Drawing.Point(233, 180);
			this.CastleW.Name = "CastleW";
			this.CastleW.Size = new System.Drawing.Size(171, 197);
			this.CastleW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.CastleW.TabIndex = 10;
			this.CastleW.TabStop = false;
			this.CastleW.Visible = false;
			// 
			// KingB
			// 
			this.KingB.ErrorImage = null;
			this.KingB.Image = ((System.Drawing.Image)(resources.GetObject("KingB.Image")));
			this.KingB.InitialImage = null;
			this.KingB.Location = new System.Drawing.Point(461, 180);
			this.KingB.Name = "KingB";
			this.KingB.Size = new System.Drawing.Size(137, 247);
			this.KingB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.KingB.TabIndex = 13;
			this.KingB.TabStop = false;
			this.KingB.Visible = false;
			// 
			// KingW
			// 
			this.KingW.ErrorImage = null;
			this.KingW.Image = ((System.Drawing.Image)(resources.GetObject("KingW.Image")));
			this.KingW.InitialImage = null;
			this.KingW.Location = new System.Drawing.Point(233, 181);
			this.KingW.Name = "KingW";
			this.KingW.Size = new System.Drawing.Size(140, 252);
			this.KingW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.KingW.TabIndex = 12;
			this.KingW.TabStop = false;
			this.KingW.Visible = false;
			// 
			// PawnB
			// 
			this.PawnB.ErrorImage = null;
			this.PawnB.Image = ((System.Drawing.Image)(resources.GetObject("PawnB.Image")));
			this.PawnB.InitialImage = null;
			this.PawnB.Location = new System.Drawing.Point(458, 181);
			this.PawnB.Name = "PawnB";
			this.PawnB.Size = new System.Drawing.Size(139, 170);
			this.PawnB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.PawnB.TabIndex = 15;
			this.PawnB.TabStop = false;
			this.PawnB.Visible = false;
			// 
			// PawnW
			// 
			this.PawnW.ErrorImage = null;
			this.PawnW.Image = ((System.Drawing.Image)(resources.GetObject("PawnW.Image")));
			this.PawnW.InitialImage = null;
			this.PawnW.Location = new System.Drawing.Point(233, 180);
			this.PawnW.Name = "PawnW";
			this.PawnW.Size = new System.Drawing.Size(145, 169);
			this.PawnW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
			this.PawnW.TabIndex = 14;
			this.PawnW.TabStop = false;
			this.PawnW.Visible = false;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(786, 98);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(386, 17);
			this.label1.TabIndex = 16;
			this.label1.Text = "http://www.chesscoachonline.com/chess-articles/chess-rules";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1290, 583);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.PawnB);
			this.Controls.Add(this.PawnW);
			this.Controls.Add(this.KingB);
			this.Controls.Add(this.KingW);
			this.Controls.Add(this.KnightB);
			this.Controls.Add(this.CastleW);
			this.Controls.Add(this.BishopB);
			this.Controls.Add(this.BishopW);
			this.Controls.Add(this.QueenB);
			this.Controls.Add(this.QueenW);
			this.Controls.Add(this.CastleB);
			this.Controls.Add(this.cbChessPiece);
			this.Controls.Add(this.edtrich);
			this.Controls.Add(this.KnightW);
			this.Controls.Add(this.lblQuestion);
			this.Controls.Add(this.btnShow);
			this.Name = "Form1";
			this.Text = "Form1";
			((System.ComponentModel.ISupportInitialize)(this.KnightW)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.CastleB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.QueenB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.QueenW)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.BishopB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.BishopW)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.KnightB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.CastleW)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.KingB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.KingW)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PawnB)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.PawnW)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnShow;
		private System.Windows.Forms.Label lblQuestion;
		private System.Windows.Forms.PictureBox KnightW;
		private System.Windows.Forms.RichTextBox edtrich;
		private System.Windows.Forms.ComboBox cbChessPiece;
		private System.Windows.Forms.PictureBox CastleB;
		private System.Windows.Forms.PictureBox QueenB;
		private System.Windows.Forms.PictureBox QueenW;
		private System.Windows.Forms.PictureBox BishopB;
		private System.Windows.Forms.PictureBox BishopW;
		private System.Windows.Forms.PictureBox KnightB;
		private System.Windows.Forms.PictureBox CastleW;
		private System.Windows.Forms.PictureBox KingB;
		private System.Windows.Forms.PictureBox KingW;
		private System.Windows.Forms.PictureBox PawnB;
		private System.Windows.Forms.PictureBox PawnW;
		private System.Windows.Forms.Label label1;
	}
}

