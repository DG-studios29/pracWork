﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Chess
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btnShow_Click(object sender, EventArgs e)
		{
			
			switch (cbChessPiece.SelectedItem)
			{
				case "King":
					{ KingB.Visible = true;
						KingW.Visible = true;
						edtrich.Text = "King can move exactly one square horizontally, vertically, or diagonally. \rAt most once in every game, each king is allowed to make a special move, known as castling.";
						QueenB.Visible = false;
						QueenW.Visible = false;
						BishopB.Visible = false;
						BishopW.Visible = false;
						KnightB.Visible = false;
						KnightB.Visible = false; 
						CastleB.Visible = false;
						CastleW.Visible = false;
						PawnB.Visible = false;
						PawnW.Visible = false;
					}
				break;
				case "Queen":
					
					{ QueenB.Visible = true;
						QueenW.Visible = true;
						edtrich.Text = "Queen can move any number of vacant squares diagonally, horizontally, or vertically.";
						KingB.Visible = false;
						KingW.Visible = false;
						BishopB.Visible = false;
						BishopW.Visible = false;
						KnightB.Visible = false;
						KnightB.Visible = false;
						CastleB.Visible = false;
						CastleW.Visible = false;
						PawnB.Visible = false;
						PawnW.Visible = false; 
					}
				break;
				case "Bishop":
					
					{ BishopB.Visible = true;
						BishopW.Visible = true;
						edtrich.Text = "Bishop can move any number of vacant squares in any diagonal direction.";
						KnightB.Visible = false;
						KnightB.Visible = false;
						CastleB.Visible = false;
						CastleW.Visible = false;
						PawnB.Visible = false;
						PawnW.Visible = false;
						QueenB.Visible = false;
						QueenW.Visible = false;
						KingB.Visible = false; 
					   KingW.Visible = false; 
					}
				break;
				case "Knight":
					
					{
						KnightB.Visible = true;
						KnightW.Visible = true;
						edtrich.Text = "Knight can move one square along any rank or file and then at an angle.\rThe knight´s movement can also be viewed as an “L” or “7″ laid out at any horizontal or vertical angle.";
						CastleB.Visible = false;
						CastleW.Visible = false;
						PawnB.Visible = false;
						PawnW.Visible = false;
						QueenB.Visible = false;
						QueenW.Visible = false;
						KingB.Visible = false;
						KingW.Visible = false;
						BishopB.Visible = false;
						BishopW.Visible = false;
					}
				break;
				case "Castle":
				
					{
						CastleB.Visible = true;
						CastleW.Visible = true;
						edtrich.Text = " Castle can move any number of vacant squares vertically or horizontally.It also is moved while castling.";
						PawnB.Visible = false;
						PawnW.Visible = false;
						QueenB.Visible = false;
						QueenW.Visible = false;
						KingB.Visible = false;
						KingW.Visible = false;
						BishopB.Visible = false;
						BishopW.Visible = false;
						KingB.Visible = false;
						KingW.Visible = false;
					}
				break;
				case "Pawn":
					
					{
						PawnB.Visible = true;
						PawnW.Visible = true;
						edtrich.Text = "Pawns can move forward one square, if that square is unoccupied.\r If it has not yet moved, the pawn has the option of moving two squares forward provided both squares in front of the pawn are unoccupied.\rA pawn cannot move backward.\rPawns are the only pieces that capture differently from how they move.\rThey can capture an enemy piece on either of the two spaces adjacent to the space in front of them (i.e., the two squares diagonally in front of them) but cannot move to these spaces if they are vacant.\rThe pawn is also involved in the two special moves en passant and promotion.";
						QueenB.Visible = false;
						QueenW.Visible = false;
						KingB.Visible = false;
						KingW.Visible = false;
						BishopB.Visible = false;
						BishopW.Visible = false;
						KingB.Visible = false;
						KingW.Visible = false;
						CastleB.Visible = false;
						CastleW.Visible = false;
					}
				break;

			}
			

		}
	}
}
