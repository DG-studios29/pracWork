﻿using System;

namespace Class_Validation
{
	class Program
	{
		static void Main(string[] args)
		{
			string sClass;
			string sCharacter;

			sClass = " ";
		
			

				while (sClass !="Exit")
			{
				Console.WriteLine("Hello user please enter a class:");
				Console.WriteLine("The Class are: Strength,Charisma,Wisdom,Dexterity,Intelligence");
				sClass = Console.ReadLine();

				switch (sClass)
				{
					case "Strength":
				
						Console.WriteLine("Please enter the charcter you would like to be");
						Console.WriteLine("Barbarian, Fighter, Paladin");
						sCharacter = Console.ReadLine();
						Console.WriteLine("Your character is:" + sCharacter);
							break;



					case "Charisma":
				
						Console.WriteLine("Please enter the charcter you would like to be");
						Console.WriteLine("Bard,Sorcerer,Paladin,Warlock");
						sCharacter = Console.ReadLine();
						Console.WriteLine("Your character is:" + sCharacter);

						break;
					case "Wisdom":
				
						Console.WriteLine("Please enter the charcter you would like to be");
						Console.WriteLine("Cleric,Druid,Monk,Ranger");
						sCharacter = Console.ReadLine();
						Console.WriteLine("Your character is:" + sCharacter);
						break;

					case "Dexterity":
					
						Console.WriteLine("Please enter the charcter you would like to be");
						Console.WriteLine("Monk,Fighter,Rogue,Ranger");
						sCharacter = Console.ReadLine();
						Console.WriteLine("Your character is:" + sCharacter);
						break;

					case "Intelligence":
					
						Console.WriteLine("Please enter the charcter you would like to be");
						Console.WriteLine("Wizard");
						sCharacter = Console.ReadLine();
						Console.WriteLine("Your character is:" + sCharacter);
					break;


				}
				Console.ReadKey();
				break;

			}
				
			

			


		}
	}
}
