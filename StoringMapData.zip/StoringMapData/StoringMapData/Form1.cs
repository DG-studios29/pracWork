﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StoringMapData
{
	public partial class Form1 : Form
	{
		int[,] grid = new int[4,5]  {{ 1, 2, 3, 4, 5 }, { 6, 7, 8, 9, 10, }, { 11, 12, 13, 14, 15 },{ 16, 17, 18, 19, 20 }};
		PictureBox[,] pictureBoxes = new PictureBox[4,5];
		Random rand = new Random();
	
		public Form1()
		{
			InitializeComponent();
			pictureBoxes[0, 0] = pictureBox1;
			pictureBoxes[1, 1] = pictureBox2;
			pictureBoxes[2, 2] = pictureBox3;
			pictureBoxes[3, 3] = pictureBox4;
			pictureBoxes[4, 4] = pictureBox5;
			
		}

		private void button1_Click(object sender, EventArgs e)
		{
			for (int x = 0; x < 4; ++x)
			{
				for (int y = 0; y < 5; ++y)
				{
					int random = rand.Next(0, 4);
					switch (random)
					{
						case 0:
							{
								pictureBoxes[x, y].Visible = true;
									
							}
							break;
						case 1:
							{
								pictureBoxes[x, y].Visible = true;
							
							}
							break;
						case 2:
							{
								pictureBoxes[x, y].Visible = true;


							}
							break;
						case 3:
							{
								pictureBoxes[x, y].Visible = true;


							}
							break;
						case 4:
							{
								pictureBoxes[x, y].Visible = true;


							}
							break;

					}
				}
			}
			
			



		}
	}
}
