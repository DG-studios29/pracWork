﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Trade_Calcuator
{
	public partial class Form1 : Form
	{
		
		Random randomPBS = new Random();
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			int randomM = Convert.ToInt32(textBox1.Text);
			int randomP = randomPBS.Next(0, 21);
			textBox2.Text = randomP.ToString();
			int price = Convert.ToInt32(textBox3.Text);

			if ((randomP <= 10) && (randomP < randomM))
			{
				label1.Text = "The player is at a serious disadvantage.\rThe cost of buying items increase by 50 %.\rThe item cost is:" + (price + 500); ;
				 
			}
			if ((randomP > 4) && (randomP <= 10) && (randomP <randomM))
			{ label1.Text = "The player is at a disadvantage.\rThe cost of buying items increase by 20 %.\rThe item cost is:" + (price + 200);
			
			}
			if ((randomP >= 10) && (randomP == randomM))
			{ label1.Text = "This is considered fair.\rThe cost of buying items remain unchanged.\rThe item cost is:" + (price); 
			
			}
			if ((randomP > 4) && (randomP >= 10) && (randomP > randomM))
			{ label1.Text = "The player is at an advantage.\rThe cost of buying items decrease by 10%.\rThe item cost is:" + (price - 100); 
			
			}
			if ((randomP > 10) && (randomP > randomM))
			{ label1.Text = " The player is at a serious advantage.\rThe cost of buying items decrease by 30 %.\rThe item cost is:" + (price - 300); 
			
			}














		}

		private void textBox1_TextChanged(object sender, EventArgs e)
		{
		
		}

		private void textBox2_TextChanged(object sender, EventArgs e)
		{
			
		}
	}
	
}
