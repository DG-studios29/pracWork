﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dhillan_Gopal_19017017_Exam_GADE5111
{
	public partial class Minesweeper : Form
	{
		int width;
		int height;
		int nMines;
		char[,] gameMap;
		char[,] userGuesses;
		Random roll = new Random();
		int actionsRemainung;
		int correct = 0;
		int userScore;
		int xPosition = 0;
		int yPosition = 0;
		Boolean win = false;


		public Minesweeper()
		{
			InitializeComponent();
		}
		public void startGame(int widthMin, int widthMax, int heightMin, int heightMax, int numofMines)
		{

			userScore = 0;
			nMines = numofMines;
			width = randomRoll(widthMin, widthMax + 1);
			height = randomRoll(heightMin, heightMax + 1);
			actionsRemainung = width * height;

			gameMap = new char[height, width];
			userGuesses = new char[height, width];

			initialiseMap(nMines);


		}
		void initialiseMap(int numofmines)
		{

			for (int y = 0; y < height; y++)
			{
				for (int x = 0; x < width; x++)
				{
					gameMap[y, x] = '.';
				}
			}
			fillMapWithMines(numofmines);
			reDraw(true);
		}

		int randomRoll(int value1, int value2)
		{
			return roll.Next(value1, value2);

		}

		void fillMapWithMines(int numofmines)
		{
			int minesPlaced = 0;

			while (minesPlaced < numofmines)
			{
				int x = randomRoll(0, width - 1);
				int y = randomRoll(0, height - 1);
				if (gameMap[y, x] != 'X')
				{
					placeMine(y, x, 'X');
					minesPlaced++;
				}

			}

		}

		void placeMine(int x, int y, char sym)
		{
			gameMap[x, y] = sym;
		}
		private TileCreate(TileEnum type)
		{

		}
		void reDraw(bool hideMines)
		{
			lblMap.Text = "";
			string display = "";

			for (int i = 0; i < height; ++i)
			{
				for (int j = 0; j < width; ++j)
				{
					if (gameMap[i, j] == 'X' && userGuesses[i, j] != 'F' && hideMines)
					{
						display += ". ";
					}
					else if (gameMap[i, j] == 'X' && userGuesses[i, j] == 'F' && hideMines)
					{
						display += "F ";
					}
					else
					{
						display += gameMap[i, j] + " ";
					}
				}
				display += '\n';
			}

			lblMap.Text = display;
		}

		int numFlagged()
		{
			int mines = 0;
			for (int x = 0; x < width; x++)
			{
				for (int y = 0; y < height; y++)
				{
					if (userGuesses[y, x] == 'F')
					{
						mines++;
					}
				}
			}
			return mines;


		}
		void guess(int x, int y)
		{
			if (userScore > 0)
			{
				updatePanel();

				if (actionsRemainung > 0)
				{
					if (gameMap[y, x] == 'X')
					{
						userGuesses[y, x] = 'F';
					}

					reDraw(true);
				}

				if (numFlagged() == nMines)
				{
					gameOver(true);
				}
			}
		}


		void updatePanel()
		{
			userScore = userScore - 1;
			actionsRemainung = actionsRemainung - 1;
			lblScore.Text = "Score: " + userScore.ToString();
			lblActionRemaining.Text = "Actions Remaining: " + actionsRemainung.ToString();
		}
		void revealMap()
		{
			reDraw(false);
		}

		void revealTile(int x, int y, bool checkmine)
		{

			int result = CheckForMines(x, y);

			actionsRemainung = actionsRemainung - 1;
			lblActionRemaining.Text = "Actions Remaining: " + actionsRemainung.ToString();

			if (result != 9)
			{
				++userScore;
				++correct;

				lblScore.Text = "Score: " + userScore.ToString();

				if (result != 0)
				{
					gameMap[y, x] = gameMap[y, x] = (char)(48 + result);
				}
				else
				{
					gameMap[y, x] = ' ';
				}
				if (checkWin())
				{
					gameOver(true);
				}
				else if (actionsRemainung == 0)
				{
					gameOver(false);
				}
				else
				{
					reDraw(true);
				}

			}
			else
			{
				gameOver(false);

			}
		}


		private Boolean checkWin()
		{

			if (correct == ((width * height) - nMines))
			{
				return true;
			}
			else
			{
				return false;
			}

		}

		private void gameOver(Boolean is_win)
		{
			btnRevealTile.Enabled = false;
			btnFlagMine.Enabled = false;
			win = is_win;
			if (win)
			{
				revealMap();
			}
			else
			{
				reDraw(true);
			}


		}
		int CheckForMines(int x, int y)
		{
			int mines = 0;

			// check mines in all directions

			if (y - 1 != -1 && x - 1 != -1) { mines += Check(y - 1, x - 1); } // NW
			if (y - 1 != -1) { mines += Check(y - 1, x); }   // N
			if (y - 1 != -1 && x + 1 != width) { mines += Check(y - 1, x + 1); }  // NE
			if (x - 1 != -1) { mines += Check(y, x - 1); }    // W
			if (x + 1 != width) { mines += Check(y, x + 1); }    // E
			if (y + 1 != height && x - 1 != -1) { mines += Check(y + 1, x - 1); }  // SW
			if (y + 1 != height) { mines += Check(y + 1, x); }     // S
			if (y + 1 != height && x + 1 != width) { mines += Check(y + 1, x + 1); } // SE

			if (Check(y, x) == 1)
			{
				return 9;
			}
			else
			{
				return mines;
			}
		}

		private int Check(int y, int x)
		{
			if (gameMap[y, x] == 'X')
			{
				return 1;
			}
			else
			{
				return 0;
			}
		}

		private void btnRevealTile_Click(object sender, EventArgs e)
		{
			xPosition = Convert.ToInt32(edtXPosition.Text);
			yPosition = Convert.ToInt32(edtYPosition.Text);
			revealTile(xPosition, yPosition, true);

		}

		private void btnFlagMine_Click(object sender, EventArgs e)
		{

			int x = Convert.ToInt32(edtXPosition.Text);
			int y = Convert.ToInt32(edtYPosition.Text);

			guess(x, y);


		}

	}
}
