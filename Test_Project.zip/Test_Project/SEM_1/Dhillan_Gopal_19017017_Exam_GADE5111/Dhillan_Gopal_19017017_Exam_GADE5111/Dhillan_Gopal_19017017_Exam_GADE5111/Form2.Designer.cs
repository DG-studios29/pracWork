﻿namespace Dhillan_Gopal_19017017_Exam_GADE5111
{
	partial class Minesweeper
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.edtXPosition = new System.Windows.Forms.TextBox();
			this.edtYPosition = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.lblScore = new System.Windows.Forms.Label();
			this.lblActionRemaining = new System.Windows.Forms.Label();
			this.lblYPosition = new System.Windows.Forms.Label();
			this.lblXPosition = new System.Windows.Forms.Label();
			this.btnRevealTile = new System.Windows.Forms.Button();
			this.btnFlagMine = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// edtXPosition
			// 
			this.edtXPosition.Location = new System.Drawing.Point(731, 308);
			this.edtXPosition.Name = "edtXPosition";
			this.edtXPosition.Size = new System.Drawing.Size(100, 22);
			this.edtXPosition.TabIndex = 0;
			// 
			// edtYPosition
			// 
			this.edtYPosition.Location = new System.Drawing.Point(865, 308);
			this.edtYPosition.Name = "edtYPosition";
			this.edtYPosition.Size = new System.Drawing.Size(100, 22);
			this.edtYPosition.TabIndex = 0;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.label1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.Location = new System.Drawing.Point(306, 188);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(2, 24);
			this.label1.TabIndex = 1;
			// 
			// lblScore
			// 
			this.lblScore.AutoSize = true;
			this.lblScore.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblScore.Location = new System.Drawing.Point(726, 54);
			this.lblScore.Name = "lblScore";
			this.lblScore.Size = new System.Drawing.Size(75, 29);
			this.lblScore.TabIndex = 1;
			this.lblScore.Text = "Score:";
			// 
			// lblActionRemaining
			// 
			this.lblActionRemaining.AutoSize = true;
			this.lblActionRemaining.Font = new System.Drawing.Font("Arial Narrow", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblActionRemaining.Location = new System.Drawing.Point(726, 106);
			this.lblActionRemaining.Name = "lblActionRemaining";
			this.lblActionRemaining.Size = new System.Drawing.Size(186, 29);
			this.lblActionRemaining.TabIndex = 1;
			this.lblActionRemaining.Text = "Action Remaining:";
			// 
			// lblYPosition
			// 
			this.lblYPosition.AutoSize = true;
			this.lblYPosition.Location = new System.Drawing.Point(862, 256);
			this.lblYPosition.Name = "lblYPosition";
			this.lblYPosition.Size = new System.Drawing.Size(71, 17);
			this.lblYPosition.TabIndex = 1;
			this.lblYPosition.Text = "Y Position";
			// 
			// lblXPosition
			// 
			this.lblXPosition.AutoSize = true;
			this.lblXPosition.Location = new System.Drawing.Point(728, 256);
			this.lblXPosition.Name = "lblXPosition";
			this.lblXPosition.Size = new System.Drawing.Size(71, 17);
			this.lblXPosition.TabIndex = 1;
			this.lblXPosition.Text = "X Position";
			// 
			// btnRevealTile
			// 
			this.btnRevealTile.Location = new System.Drawing.Point(731, 373);
			this.btnRevealTile.Name = "btnRevealTile";
			this.btnRevealTile.Size = new System.Drawing.Size(234, 29);
			this.btnRevealTile.TabIndex = 2;
			this.btnRevealTile.Text = "Reveal Tile";
			this.btnRevealTile.UseVisualStyleBackColor = true;
			this.btnRevealTile.Click += new System.EventHandler(this.btnRevealTile_Click);
			// 
			// btnFlagMine
			// 
			this.btnFlagMine.Location = new System.Drawing.Point(731, 444);
			this.btnFlagMine.Name = "btnFlagMine";
			this.btnFlagMine.Size = new System.Drawing.Size(234, 32);
			this.btnFlagMine.TabIndex = 2;
			this.btnFlagMine.Text = "Flag Mine";
			this.btnFlagMine.UseVisualStyleBackColor = true;
			this.btnFlagMine.Click += new System.EventHandler(this.btnFlagMine_Click);
			// 
			// Minesweeper
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1066, 649);
			this.Controls.Add(this.btnFlagMine);
			this.Controls.Add(this.btnRevealTile);
			this.Controls.Add(this.lblScore);
			this.Controls.Add(this.lblActionRemaining);
			this.Controls.Add(this.lblXPosition);
			this.Controls.Add(this.lblYPosition);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.edtYPosition);
			this.Controls.Add(this.edtXPosition);
			this.Name = "Minesweeper";
			this.Text = "Minesweeper";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox edtXPosition;
		private System.Windows.Forms.TextBox edtYPosition;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label lblScore;
		private System.Windows.Forms.Label lblActionRemaining;
		private System.Windows.Forms.Label lblYPosition;
		private System.Windows.Forms.Label lblXPosition;
		private System.Windows.Forms.Button btnRevealTile;
		private System.Windows.Forms.Button btnFlagMine;
	}
}