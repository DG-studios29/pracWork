﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dhillan_Gopal_19017017_Exam_GADE5111
{
	public partial class FrmGameParameters : Form
	{
		int widthMin;
		int widthMax;
		int heightMin;
		int heightMax;
		int numofMines;
		public FrmGameParameters()
		{
			InitializeComponent();
		}
		private void btnStartGame_Click(object sender, EventArgs e)
		{
			widthMin = Convert.ToInt32(edtWidthMin.Text);
			widthMax = Convert.ToInt32(edtWidthMax.Text);
			heightMin = Convert.ToInt32(edtHeightMin.Text);
			heightMax = Convert.ToInt32(edtHeightMax.Text);
			numofMines = Convert.ToInt32(edtNumOfMines.Text);
			Minesweeper next = new Minesweeper();
			next.Show();
			next.startGame(widthMin, widthMax, heightMin, heightMax, numofMines);
			this.Hide();
			
				
		}
	}
}
