﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dhillan_Gopal_19017017_Exam_GADE5111
{
	public partial class Minesweeper : Form
	{
		int[,] gameMap;
		int[,] userGuesses;
		Random roll = new Random();
		int actionsRemainung;
		int userScore;
		int xPosition;
		int yPosition;
		int width;
		int height;
		int nMines;
		public Minesweeper()
		{
			InitializeComponent();
		}
		public void startGame(int widthMin, int widthMax, int heightMin, int heightMax, int numofMines)
		{
			width = widthMin + widthMax;
			height = heightMin + heightMax;
			numofMines = nMines;
			fillMapWithMines();
			
		}
		void initialiseMap()
		{


		}

		void randomRol()
		{
			roll.Next(width, height);
		}
		void fillMapWithMines()
		{
			int column, row;
			for (column = 0; column < height; column++)
			{
				for (row = 0; row < width; row++)
					userGuesses[column, row] = '.';
			}

			for (row = 0; row < width; row++)
			{
				userGuesses[Convert.ToInt32(roll), row] = 'F';

			}
			void reDraw()
			{

			}
		}
		int numFlagged(int row, int column)
		{
			int mines = 0;
			if (row - 1 >= 0 && userGuesses[row - 1,column] == 'F')

				mines++;

			if (row + 1 < width && userGuesses[row + 1,column] == 'F')

				mines++;
			if (column - 1 >= 0 && userGuesses[row, column-1] == 'F')

				mines++;

			if (column + 1 < height && userGuesses[row, column+1] == 'F')

				mines++;

			//// Check up, down, left, right.
			//if (userGuesses[row - 1, column] == 'F')
			//	mines++;
			//if (userGuesses[row + 1, column] == 'F')
			//	mines++;
			//if (userGuesses[row, column - 1] == 'F')
			//	mines++;
			//if (userGuesses[row, column + 1] == 'F')
			//	mines++;

			// Check all diagonal directions
			if (userGuesses[row - 1, column + 1] == 'F')
				mines++;
			if (userGuesses[row - 1, column - 1] == 'F')
				mines++;
			if (userGuesses[row + 1, column + 1] == 'F')
				mines++;
			if (userGuesses[row + 1, column - 1] == 'F')
				mines++;

			return mines;

		}
		void guess()
		{

		}
		void placeMine()
		{
			while (xPosition < 0 || xPosition > width - 1 || yPosition < 0 || yPosition > height - 1) ;


			if (userGuesses[xPosition,yPosition] == 'F')
			{
				//printf("You have hit a mine!\n\n");
				//printBoard();
				gameOver();
			}
			else
				CheckForMines(xPosition, yPosition);
		}
		bool gameOver()
		{
			int column, row;
			for (column = 1; column < height - 1; column++)
				for (row = 1; row < width - 1; row++)
				{
					if (gameMap[column,row] == '.' && userGuesses[column,row] != 'F')
					{
						return false;
					}
						
				}
			return true;
		}
		void revealMap()
		{
			int column, row;
			// Set all elements in the board to '.'
			for (column = 0; column < height; column++)
				for (row = 0; row < width; row++)
					gameMap[column,row] = '.';
		}
	
		void revealTile()
		{

		}
		int CheckForMines(int row, int column)
		{
			int nearbymines = 0;
			if (row < 0 || row >= width || column < 0 || column >= height || gameMap[column, row] != '.')
			{
				return 0;
			}
			nearbymines = numFlagged(row, column);
			gameMap[column, row] = (char)(((int)'0') + nearbymines);
			//Want to check each mine see if 0, if 0 check each space around it
			if (nearbymines < 1)
			{
				CheckForMines(column, row - 1);
				CheckForMines(column + 1, row - 1);
				CheckForMines(column + 1, row);
				CheckForMines(column + 1, row + 1);
				CheckForMines(column, row + 1);
				CheckForMines(column - 1, row + 1);
				CheckForMines(column - 1, row);
				CheckForMines(column - 1, row - 1);
			}
			return Convert.ToInt32("X");
		}

		private void btnRevealTile_Click(object sender, EventArgs e)
		{
			revealTile();
		}

		private void btnFlagMine_Click(object sender, EventArgs e)
		{


		}

	}
}
