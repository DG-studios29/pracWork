﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AwesomeProject
{
    public partial class AwesomeCalculator : Form
    {
        public AwesomeCalculator()
        {
            InitializeComponent();
        }

        private void AddButton_Click(object sender, EventArgs e)
        {
            int number1 = Convert.ToInt32(number1TextBox.Text);
            int number2 = Convert.ToInt32(number2TextBox.Text);

            int answer = number1 + number2;

            answerLabel.Text = answer.ToString();
        }

        private void MultiplyButton_Click(object sender, EventArgs e)
        {
            int number1 = Convert.ToInt32(number1TextBox.Text);
            int number2 = Convert.ToInt32(number2TextBox.Text);

            int answer = number1 * number2;

            answerLabel.Text = answer.ToString();
        }

        private void FactorialButton_Click(object sender, EventArgs e)
        {
            int number1 = Convert.ToInt32(number1TextBox.Text);
            int i = 0;
            int answer = number1;

            while (i < number1)
            {
                ++i;
                answer *= number1;
            }

            answerLabel.Text = answer.ToString();
        }
    }
}
