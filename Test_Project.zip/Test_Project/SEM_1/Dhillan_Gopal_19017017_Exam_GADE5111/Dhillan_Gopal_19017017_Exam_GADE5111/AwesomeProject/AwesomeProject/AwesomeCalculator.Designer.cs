﻿namespace AwesomeProject
{
    partial class AwesomeCalculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.number1Label = new System.Windows.Forms.Label();
            this.number1TextBox = new System.Windows.Forms.TextBox();
            this.number2TextBox = new System.Windows.Forms.TextBox();
            this.number2Label = new System.Windows.Forms.Label();
            this.addButton = new System.Windows.Forms.Button();
            this.answerDescriptionLabel = new System.Windows.Forms.Label();
            this.answerLabel = new System.Windows.Forms.Label();
            this.multiplyButton = new System.Windows.Forms.Button();
            this.factorialButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // number1Label
            // 
            this.number1Label.AutoSize = true;
            this.number1Label.Location = new System.Drawing.Point(24, 26);
            this.number1Label.Name = "number1Label";
            this.number1Label.Size = new System.Drawing.Size(56, 13);
            this.number1Label.TabIndex = 0;
            this.number1Label.Text = "Number 1:";
            // 
            // number1TextBox
            // 
            this.number1TextBox.Location = new System.Drawing.Point(27, 54);
            this.number1TextBox.Name = "number1TextBox";
            this.number1TextBox.Size = new System.Drawing.Size(100, 20);
            this.number1TextBox.TabIndex = 1;
            // 
            // number2TextBox
            // 
            this.number2TextBox.Location = new System.Drawing.Point(208, 54);
            this.number2TextBox.Name = "number2TextBox";
            this.number2TextBox.Size = new System.Drawing.Size(100, 20);
            this.number2TextBox.TabIndex = 2;
            // 
            // number2Label
            // 
            this.number2Label.AutoSize = true;
            this.number2Label.Location = new System.Drawing.Point(205, 26);
            this.number2Label.Name = "number2Label";
            this.number2Label.Size = new System.Drawing.Size(56, 13);
            this.number2Label.TabIndex = 3;
            this.number2Label.Text = "Number 2:";
            // 
            // addButton
            // 
            this.addButton.Location = new System.Drawing.Point(27, 114);
            this.addButton.Name = "addButton";
            this.addButton.Size = new System.Drawing.Size(75, 23);
            this.addButton.TabIndex = 4;
            this.addButton.Text = "Add";
            this.addButton.UseVisualStyleBackColor = true;
            this.addButton.Click += new System.EventHandler(this.AddButton_Click);
            // 
            // answerDescriptionLabel
            // 
            this.answerDescriptionLabel.AutoSize = true;
            this.answerDescriptionLabel.Location = new System.Drawing.Point(24, 172);
            this.answerDescriptionLabel.Name = "answerDescriptionLabel";
            this.answerDescriptionLabel.Size = new System.Drawing.Size(45, 13);
            this.answerDescriptionLabel.TabIndex = 5;
            this.answerDescriptionLabel.Text = "Answer:";
            // 
            // answerLabel
            // 
            this.answerLabel.AutoSize = true;
            this.answerLabel.Location = new System.Drawing.Point(75, 172);
            this.answerLabel.Name = "answerLabel";
            this.answerLabel.Size = new System.Drawing.Size(142, 13);
            this.answerLabel.TabIndex = 6;
            this.answerLabel.Text = "No calculation performed yet";
            // 
            // multiplyButton
            // 
            this.multiplyButton.Location = new System.Drawing.Point(130, 114);
            this.multiplyButton.Name = "multiplyButton";
            this.multiplyButton.Size = new System.Drawing.Size(75, 23);
            this.multiplyButton.TabIndex = 7;
            this.multiplyButton.Text = "Multiply";
            this.multiplyButton.UseVisualStyleBackColor = true;
            this.multiplyButton.Click += new System.EventHandler(this.MultiplyButton_Click);
            // 
            // factorialButton
            // 
            this.factorialButton.Location = new System.Drawing.Point(233, 114);
            this.factorialButton.Name = "factorialButton";
            this.factorialButton.Size = new System.Drawing.Size(75, 23);
            this.factorialButton.TabIndex = 8;
            this.factorialButton.Text = "Factorial";
            this.factorialButton.UseVisualStyleBackColor = true;
            this.factorialButton.Click += new System.EventHandler(this.FactorialButton_Click);
            // 
            // AwesomeCalculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(370, 226);
            this.Controls.Add(this.factorialButton);
            this.Controls.Add(this.multiplyButton);
            this.Controls.Add(this.answerLabel);
            this.Controls.Add(this.answerDescriptionLabel);
            this.Controls.Add(this.addButton);
            this.Controls.Add(this.number2Label);
            this.Controls.Add(this.number2TextBox);
            this.Controls.Add(this.number1TextBox);
            this.Controls.Add(this.number1Label);
            this.Name = "AwesomeCalculator";
            this.Text = "AwesomeCalculator";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label number1Label;
        private System.Windows.Forms.TextBox number1TextBox;
        private System.Windows.Forms.TextBox number2TextBox;
        private System.Windows.Forms.Label number2Label;
        private System.Windows.Forms.Button addButton;
        private System.Windows.Forms.Label answerDescriptionLabel;
        private System.Windows.Forms.Label answerLabel;
        private System.Windows.Forms.Button multiplyButton;
        private System.Windows.Forms.Button factorialButton;
    }
}

