﻿namespace Dhillan_Gopal_19017017_Exam_GADE5111
{
	partial class FrmGameParameters
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblMapSize = new System.Windows.Forms.Label();
			this.lblHeightMin = new System.Windows.Forms.Label();
			this.lblHeight = new System.Windows.Forms.Label();
			this.lblWidthMin = new System.Windows.Forms.Label();
			this.lblWidth = new System.Windows.Forms.Label();
			this.HeightMax = new System.Windows.Forms.Label();
			this.lblNumOfMines = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.lblWidthMax = new System.Windows.Forms.Label();
			this.btnStartGame = new System.Windows.Forms.Button();
			this.edtWidthMin = new System.Windows.Forms.TextBox();
			this.edtHeightMin = new System.Windows.Forms.TextBox();
			this.edtHeightMax = new System.Windows.Forms.TextBox();
			this.edtWidthMax = new System.Windows.Forms.TextBox();
			this.edtNumOfMines = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// lblMapSize
			// 
			this.lblMapSize.AutoSize = true;
			this.lblMapSize.Location = new System.Drawing.Point(167, 38);
			this.lblMapSize.Name = "lblMapSize";
			this.lblMapSize.Size = new System.Drawing.Size(70, 17);
			this.lblMapSize.TabIndex = 0;
			this.lblMapSize.Text = "Map Size ";
			// 
			// lblHeightMin
			// 
			this.lblHeightMin.AutoSize = true;
			this.lblHeightMin.Location = new System.Drawing.Point(113, 134);
			this.lblHeightMin.Name = "lblHeightMin";
			this.lblHeightMin.Size = new System.Drawing.Size(30, 17);
			this.lblHeightMin.TabIndex = 0;
			this.lblHeightMin.Text = "Min";
			// 
			// lblHeight
			// 
			this.lblHeight.AutoSize = true;
			this.lblHeight.Location = new System.Drawing.Point(33, 134);
			this.lblHeight.Name = "lblHeight";
			this.lblHeight.Size = new System.Drawing.Size(53, 17);
			this.lblHeight.TabIndex = 0;
			this.lblHeight.Text = "Height:";
			// 
			// lblWidthMin
			// 
			this.lblWidthMin.AutoSize = true;
			this.lblWidthMin.Location = new System.Drawing.Point(113, 93);
			this.lblWidthMin.Name = "lblWidthMin";
			this.lblWidthMin.Size = new System.Drawing.Size(30, 17);
			this.lblWidthMin.TabIndex = 0;
			this.lblWidthMin.Text = "Min";
			// 
			// lblWidth
			// 
			this.lblWidth.AutoSize = true;
			this.lblWidth.Location = new System.Drawing.Point(33, 93);
			this.lblWidth.Name = "lblWidth";
			this.lblWidth.Size = new System.Drawing.Size(48, 17);
			this.lblWidth.TabIndex = 0;
			this.lblWidth.Text = "Width:";
			// 
			// HeightMax
			// 
			this.HeightMax.AutoSize = true;
			this.HeightMax.Location = new System.Drawing.Point(226, 134);
			this.HeightMax.Name = "HeightMax";
			this.HeightMax.Size = new System.Drawing.Size(33, 17);
			this.HeightMax.TabIndex = 0;
			this.HeightMax.Text = "Max";
			// 
			// lblNumOfMines
			// 
			this.lblNumOfMines.AutoSize = true;
			this.lblNumOfMines.Location = new System.Drawing.Point(33, 183);
			this.lblNumOfMines.Name = "lblNumOfMines";
			this.lblNumOfMines.Size = new System.Drawing.Size(119, 17);
			this.lblNumOfMines.TabIndex = 0;
			this.lblNumOfMines.Text = "Number of Mines:";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(226, 243);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(0, 17);
			this.label10.TabIndex = 0;
			// 
			// lblWidthMax
			// 
			this.lblWidthMax.AutoSize = true;
			this.lblWidthMax.Location = new System.Drawing.Point(226, 93);
			this.lblWidthMax.Name = "lblWidthMax";
			this.lblWidthMax.Size = new System.Drawing.Size(33, 17);
			this.lblWidthMax.TabIndex = 0;
			this.lblWidthMax.Text = "Max";
			// 
			// btnStartGame
			// 
			this.btnStartGame.Location = new System.Drawing.Point(141, 234);
			this.btnStartGame.Name = "btnStartGame";
			this.btnStartGame.Size = new System.Drawing.Size(132, 36);
			this.btnStartGame.TabIndex = 1;
			this.btnStartGame.Text = "Start Game";
			this.btnStartGame.UseVisualStyleBackColor = true;
			this.btnStartGame.Click += new System.EventHandler(this.btnStartGame_Click);
			// 
			// edtWidthMin
			// 
			this.edtWidthMin.Location = new System.Drawing.Point(160, 90);
			this.edtWidthMin.Name = "edtWidthMin";
			this.edtWidthMin.Size = new System.Drawing.Size(48, 22);
			this.edtWidthMin.TabIndex = 2;
			this.edtWidthMin.Text = "0";
			// 
			// edtHeightMin
			// 
			this.edtHeightMin.Location = new System.Drawing.Point(160, 131);
			this.edtHeightMin.Name = "edtHeightMin";
			this.edtHeightMin.Size = new System.Drawing.Size(48, 22);
			this.edtHeightMin.TabIndex = 2;
			this.edtHeightMin.Text = "0";
			// 
			// edtHeightMax
			// 
			this.edtHeightMax.Location = new System.Drawing.Point(278, 134);
			this.edtHeightMax.Name = "edtHeightMax";
			this.edtHeightMax.Size = new System.Drawing.Size(48, 22);
			this.edtHeightMax.TabIndex = 2;
			this.edtHeightMax.Text = "0";
			// 
			// edtWidthMax
			// 
			this.edtWidthMax.Location = new System.Drawing.Point(278, 88);
			this.edtWidthMax.Name = "edtWidthMax";
			this.edtWidthMax.Size = new System.Drawing.Size(48, 22);
			this.edtWidthMax.TabIndex = 2;
			this.edtWidthMax.Text = "0";
			// 
			// edtNumOfMines
			// 
			this.edtNumOfMines.Location = new System.Drawing.Point(278, 178);
			this.edtNumOfMines.Name = "edtNumOfMines";
			this.edtNumOfMines.Size = new System.Drawing.Size(48, 22);
			this.edtNumOfMines.TabIndex = 2;
			this.edtNumOfMines.Text = "0";
			// 
			// FrmGameParameters
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(447, 361);
			this.Controls.Add(this.edtNumOfMines);
			this.Controls.Add(this.edtWidthMax);
			this.Controls.Add(this.edtHeightMax);
			this.Controls.Add(this.edtHeightMin);
			this.Controls.Add(this.edtWidthMin);
			this.Controls.Add(this.btnStartGame);
			this.Controls.Add(this.lblWidthMax);
			this.Controls.Add(this.lblNumOfMines);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.HeightMax);
			this.Controls.Add(this.lblWidth);
			this.Controls.Add(this.lblWidthMin);
			this.Controls.Add(this.lblHeight);
			this.Controls.Add(this.lblHeightMin);
			this.Controls.Add(this.lblMapSize);
			this.Name = "FrmGameParameters";
			this.Text = "Minesweeper";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblMapSize;
		private System.Windows.Forms.Label lblHeightMin;
		private System.Windows.Forms.Label lblHeight;
		private System.Windows.Forms.Label lblWidthMin;
		private System.Windows.Forms.Label lblWidth;
		private System.Windows.Forms.Label HeightMax;
		private System.Windows.Forms.Label lblNumOfMines;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label lblWidthMax;
		private System.Windows.Forms.Button btnStartGame;
		private System.Windows.Forms.TextBox edtWidthMin;
		private System.Windows.Forms.TextBox edtHeightMin;
		private System.Windows.Forms.TextBox edtHeightMax;
		private System.Windows.Forms.TextBox edtWidthMax;
		private System.Windows.Forms.TextBox edtNumOfMines;
	}
}

