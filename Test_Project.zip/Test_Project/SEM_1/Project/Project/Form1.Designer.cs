﻿namespace Project
{
	partial class Form_Menu
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_Menu));
			this.lblDragonStats = new System.Windows.Forms.Label();
			this.lblHeading2 = new System.Windows.Forms.Label();
			this.lblHeading1 = new System.Windows.Forms.Label();
			this.pnlPlayer2 = new System.Windows.Forms.Panel();
			this.edtPlayer2dragon = new System.Windows.Forms.TextBox();
			this.lblDragonListP2 = new System.Windows.Forms.Label();
			this.edtPlayer2name = new System.Windows.Forms.TextBox();
			this.lblPlayer2Dragon = new System.Windows.Forms.Label();
			this.panel4 = new System.Windows.Forms.Panel();
			this.rbtnEarth2 = new System.Windows.Forms.RadioButton();
			this.rbtnFire2 = new System.Windows.Forms.RadioButton();
			this.rbtnWind2 = new System.Windows.Forms.RadioButton();
			this.rbtnIce2 = new System.Windows.Forms.RadioButton();
			this.lblPlayer2Name = new System.Windows.Forms.Label();
			this.btnPlayer2Save = new System.Windows.Forms.Button();
			this.btnStartgame = new System.Windows.Forms.Button();
			this.pnlPlayer1 = new System.Windows.Forms.Panel();
			this.edtPlayer1dragon = new System.Windows.Forms.TextBox();
			this.edtPlayer1name = new System.Windows.Forms.TextBox();
			this.lblPlayer1Dragon = new System.Windows.Forms.Label();
			this.lblPlayer1Name = new System.Windows.Forms.Label();
			this.lblDraganListP1 = new System.Windows.Forms.Label();
			this.btnPlayer1Save = new System.Windows.Forms.Button();
			this.panel3 = new System.Windows.Forms.Panel();
			this.rbtnEarth1 = new System.Windows.Forms.RadioButton();
			this.rbtnWind1 = new System.Windows.Forms.RadioButton();
			this.rbtnIce1 = new System.Windows.Forms.RadioButton();
			this.rbtnFire1 = new System.Windows.Forms.RadioButton();
			this.pnlPlayer2.SuspendLayout();
			this.panel4.SuspendLayout();
			this.pnlPlayer1.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblDragonStats
			// 
			this.lblDragonStats.AutoSize = true;
			this.lblDragonStats.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblDragonStats.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.lblDragonStats.ForeColor = System.Drawing.SystemColors.ButtonFace;
			this.lblDragonStats.Location = new System.Drawing.Point(979, 28);
			this.lblDragonStats.Name = "lblDragonStats";
			this.lblDragonStats.Size = new System.Drawing.Size(211, 427);
			this.lblDragonStats.TabIndex = 18;
			this.lblDragonStats.Text = resources.GetString("lblDragonStats.Text");
			this.lblDragonStats.Click += new System.EventHandler(this.lblDragonStats_Click);
			// 
			// lblHeading2
			// 
			this.lblHeading2.AutoSize = true;
			this.lblHeading2.BackColor = System.Drawing.Color.Transparent;
			this.lblHeading2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblHeading2.Location = new System.Drawing.Point(512, 18);
			this.lblHeading2.Name = "lblHeading2";
			this.lblHeading2.Size = new System.Drawing.Size(60, 17);
			this.lblHeading2.TabIndex = 19;
			this.lblHeading2.Text = "Player 2";
			// 
			// lblHeading1
			// 
			this.lblHeading1.AutoSize = true;
			this.lblHeading1.BackColor = System.Drawing.Color.Transparent;
			this.lblHeading1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblHeading1.Location = new System.Drawing.Point(36, 18);
			this.lblHeading1.Name = "lblHeading1";
			this.lblHeading1.Size = new System.Drawing.Size(60, 17);
			this.lblHeading1.TabIndex = 20;
			this.lblHeading1.Text = "Player 1";
			// 
			// pnlPlayer2
			// 
			this.pnlPlayer2.BackColor = System.Drawing.Color.Transparent;
			this.pnlPlayer2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPlayer2.Controls.Add(this.edtPlayer2dragon);
			this.pnlPlayer2.Controls.Add(this.lblDragonListP2);
			this.pnlPlayer2.Controls.Add(this.edtPlayer2name);
			this.pnlPlayer2.Controls.Add(this.lblPlayer2Dragon);
			this.pnlPlayer2.Controls.Add(this.panel4);
			this.pnlPlayer2.Controls.Add(this.lblPlayer2Name);
			this.pnlPlayer2.Controls.Add(this.btnPlayer2Save);
			this.pnlPlayer2.ForeColor = System.Drawing.Color.Cyan;
			this.pnlPlayer2.Location = new System.Drawing.Point(495, 28);
			this.pnlPlayer2.Name = "pnlPlayer2";
			this.pnlPlayer2.Size = new System.Drawing.Size(443, 378);
			this.pnlPlayer2.TabIndex = 17;
			// 
			// edtPlayer2dragon
			// 
			this.edtPlayer2dragon.Location = new System.Drawing.Point(123, 104);
			this.edtPlayer2dragon.Name = "edtPlayer2dragon";
			this.edtPlayer2dragon.Size = new System.Drawing.Size(267, 22);
			this.edtPlayer2dragon.TabIndex = 4;
			// 
			// lblDragonListP2
			// 
			this.lblDragonListP2.AutoSize = true;
			this.lblDragonListP2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
			this.lblDragonListP2.Location = new System.Drawing.Point(36, 172);
			this.lblDragonListP2.Name = "lblDragonListP2";
			this.lblDragonListP2.Size = new System.Drawing.Size(81, 17);
			this.lblDragonListP2.TabIndex = 2;
			this.lblDragonListP2.Text = "Dragan List";
			// 
			// edtPlayer2name
			// 
			this.edtPlayer2name.Location = new System.Drawing.Point(123, 57);
			this.edtPlayer2name.Name = "edtPlayer2name";
			this.edtPlayer2name.Size = new System.Drawing.Size(267, 22);
			this.edtPlayer2name.TabIndex = 4;
			// 
			// lblPlayer2Dragon
			// 
			this.lblPlayer2Dragon.AutoSize = true;
			this.lblPlayer2Dragon.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblPlayer2Dragon.Location = new System.Drawing.Point(17, 106);
			this.lblPlayer2Dragon.Name = "lblPlayer2Dragon";
			this.lblPlayer2Dragon.Size = new System.Drawing.Size(100, 17);
			this.lblPlayer2Dragon.TabIndex = 3;
			this.lblPlayer2Dragon.Text = "Dragon Name:";
			// 
			// panel4
			// 
			this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel4.Controls.Add(this.rbtnEarth2);
			this.panel4.Controls.Add(this.rbtnFire2);
			this.panel4.Controls.Add(this.rbtnWind2);
			this.panel4.Controls.Add(this.rbtnIce2);
			this.panel4.Location = new System.Drawing.Point(20, 183);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(402, 142);
			this.panel4.TabIndex = 1;
			// 
			// rbtnEarth2
			// 
			this.rbtnEarth2.AutoSize = true;
			this.rbtnEarth2.ForeColor = System.Drawing.Color.Black;
			this.rbtnEarth2.Location = new System.Drawing.Point(19, 104);
			this.rbtnEarth2.Name = "rbtnEarth2";
			this.rbtnEarth2.Size = new System.Drawing.Size(114, 21);
			this.rbtnEarth2.TabIndex = 0;
			this.rbtnEarth2.TabStop = true;
			this.rbtnEarth2.Text = "Earth Dragon";
			this.rbtnEarth2.UseVisualStyleBackColor = true;
			// 
			// rbtnFire2
			// 
			this.rbtnFire2.AutoSize = true;
			this.rbtnFire2.ForeColor = System.Drawing.Color.Black;
			this.rbtnFire2.Location = new System.Drawing.Point(19, 23);
			this.rbtnFire2.Name = "rbtnFire2";
			this.rbtnFire2.Size = new System.Drawing.Size(104, 21);
			this.rbtnFire2.TabIndex = 0;
			this.rbtnFire2.TabStop = true;
			this.rbtnFire2.Text = "Fire Dragon";
			this.rbtnFire2.UseVisualStyleBackColor = true;
			// 
			// rbtnWind2
			// 
			this.rbtnWind2.AutoSize = true;
			this.rbtnWind2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.rbtnWind2.Location = new System.Drawing.Point(19, 77);
			this.rbtnWind2.Name = "rbtnWind2";
			this.rbtnWind2.Size = new System.Drawing.Size(112, 21);
			this.rbtnWind2.TabIndex = 0;
			this.rbtnWind2.TabStop = true;
			this.rbtnWind2.Text = "Wind Dragon";
			this.rbtnWind2.UseVisualStyleBackColor = true;
			// 
			// rbtnIce2
			// 
			this.rbtnIce2.AutoSize = true;
			this.rbtnIce2.ForeColor = System.Drawing.Color.Black;
			this.rbtnIce2.Location = new System.Drawing.Point(19, 50);
			this.rbtnIce2.Name = "rbtnIce2";
			this.rbtnIce2.Size = new System.Drawing.Size(98, 21);
			this.rbtnIce2.TabIndex = 0;
			this.rbtnIce2.TabStop = true;
			this.rbtnIce2.Text = "Ice Dragon";
			this.rbtnIce2.UseVisualStyleBackColor = true;
			// 
			// lblPlayer2Name
			// 
			this.lblPlayer2Name.AutoSize = true;
			this.lblPlayer2Name.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblPlayer2Name.Location = new System.Drawing.Point(24, 57);
			this.lblPlayer2Name.Name = "lblPlayer2Name";
			this.lblPlayer2Name.Size = new System.Drawing.Size(93, 17);
			this.lblPlayer2Name.TabIndex = 3;
			this.lblPlayer2Name.Text = "Player Name:";
			// 
			// btnPlayer2Save
			// 
			this.btnPlayer2Save.ForeColor = System.Drawing.Color.Black;
			this.btnPlayer2Save.Location = new System.Drawing.Point(20, 331);
			this.btnPlayer2Save.Name = "btnPlayer2Save";
			this.btnPlayer2Save.Size = new System.Drawing.Size(402, 35);
			this.btnPlayer2Save.TabIndex = 0;
			this.btnPlayer2Save.Text = "Save";
			this.btnPlayer2Save.UseVisualStyleBackColor = true;
			this.btnPlayer2Save.Click += new System.EventHandler(this.btnPlayer2Save_Click);
			// 
			// btnStartgame
			// 
			this.btnStartgame.BackColor = System.Drawing.Color.Transparent;
			this.btnStartgame.ForeColor = System.Drawing.Color.Black;
			this.btnStartgame.Location = new System.Drawing.Point(23, 412);
			this.btnStartgame.Name = "btnStartgame";
			this.btnStartgame.Size = new System.Drawing.Size(915, 50);
			this.btnStartgame.TabIndex = 15;
			this.btnStartgame.Text = "Start Game ";
			this.btnStartgame.UseVisualStyleBackColor = false;
			this.btnStartgame.Click += new System.EventHandler(this.btnStartgame_Click);
			// 
			// pnlPlayer1
			// 
			this.pnlPlayer1.BackColor = System.Drawing.Color.Transparent;
			this.pnlPlayer1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPlayer1.Controls.Add(this.edtPlayer1dragon);
			this.pnlPlayer1.Controls.Add(this.edtPlayer1name);
			this.pnlPlayer1.Controls.Add(this.lblPlayer1Dragon);
			this.pnlPlayer1.Controls.Add(this.lblPlayer1Name);
			this.pnlPlayer1.Controls.Add(this.lblDraganListP1);
			this.pnlPlayer1.Controls.Add(this.btnPlayer1Save);
			this.pnlPlayer1.Controls.Add(this.panel3);
			this.pnlPlayer1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
			this.pnlPlayer1.Location = new System.Drawing.Point(23, 28);
			this.pnlPlayer1.Name = "pnlPlayer1";
			this.pnlPlayer1.Size = new System.Drawing.Size(435, 378);
			this.pnlPlayer1.TabIndex = 16;
			// 
			// edtPlayer1dragon
			// 
			this.edtPlayer1dragon.Location = new System.Drawing.Point(119, 101);
			this.edtPlayer1dragon.Name = "edtPlayer1dragon";
			this.edtPlayer1dragon.Size = new System.Drawing.Size(267, 22);
			this.edtPlayer1dragon.TabIndex = 4;
			// 
			// edtPlayer1name
			// 
			this.edtPlayer1name.Location = new System.Drawing.Point(119, 54);
			this.edtPlayer1name.Name = "edtPlayer1name";
			this.edtPlayer1name.Size = new System.Drawing.Size(267, 22);
			this.edtPlayer1name.TabIndex = 4;
			// 
			// lblPlayer1Dragon
			// 
			this.lblPlayer1Dragon.AutoSize = true;
			this.lblPlayer1Dragon.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.lblPlayer1Dragon.Location = new System.Drawing.Point(13, 104);
			this.lblPlayer1Dragon.Name = "lblPlayer1Dragon";
			this.lblPlayer1Dragon.Size = new System.Drawing.Size(100, 17);
			this.lblPlayer1Dragon.TabIndex = 3;
			this.lblPlayer1Dragon.Text = "Dragon Name:";
			// 
			// lblPlayer1Name
			// 
			this.lblPlayer1Name.AutoSize = true;
			this.lblPlayer1Name.BackColor = System.Drawing.Color.Transparent;
			this.lblPlayer1Name.ForeColor = System.Drawing.Color.Black;
			this.lblPlayer1Name.Location = new System.Drawing.Point(18, 54);
			this.lblPlayer1Name.Name = "lblPlayer1Name";
			this.lblPlayer1Name.Size = new System.Drawing.Size(93, 17);
			this.lblPlayer1Name.TabIndex = 3;
			this.lblPlayer1Name.Text = "Player Name:";
			// 
			// lblDraganListP1
			// 
			this.lblDraganListP1.AutoSize = true;
			this.lblDraganListP1.Location = new System.Drawing.Point(30, 172);
			this.lblDraganListP1.Name = "lblDraganListP1";
			this.lblDraganListP1.Size = new System.Drawing.Size(81, 17);
			this.lblDraganListP1.TabIndex = 2;
			this.lblDraganListP1.Text = "Dragan List";
			// 
			// btnPlayer1Save
			// 
			this.btnPlayer1Save.ForeColor = System.Drawing.Color.Black;
			this.btnPlayer1Save.Location = new System.Drawing.Point(16, 331);
			this.btnPlayer1Save.Name = "btnPlayer1Save";
			this.btnPlayer1Save.Size = new System.Drawing.Size(400, 35);
			this.btnPlayer1Save.TabIndex = 0;
			this.btnPlayer1Save.Text = "Save";
			this.btnPlayer1Save.UseVisualStyleBackColor = true;
			this.btnPlayer1Save.Click += new System.EventHandler(this.btnPlayer1Save_Click);
			// 
			// panel3
			// 
			this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel3.Controls.Add(this.rbtnEarth1);
			this.panel3.Controls.Add(this.rbtnWind1);
			this.panel3.Controls.Add(this.rbtnIce1);
			this.panel3.Controls.Add(this.rbtnFire1);
			this.panel3.Location = new System.Drawing.Point(16, 183);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(400, 142);
			this.panel3.TabIndex = 1;
			// 
			// rbtnEarth1
			// 
			this.rbtnEarth1.AutoSize = true;
			this.rbtnEarth1.BackColor = System.Drawing.Color.Transparent;
			this.rbtnEarth1.ForeColor = System.Drawing.Color.Black;
			this.rbtnEarth1.Location = new System.Drawing.Point(17, 104);
			this.rbtnEarth1.Name = "rbtnEarth1";
			this.rbtnEarth1.Size = new System.Drawing.Size(114, 21);
			this.rbtnEarth1.TabIndex = 0;
			this.rbtnEarth1.TabStop = true;
			this.rbtnEarth1.Text = "Earth Dragon";
			this.rbtnEarth1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.rbtnEarth1.UseVisualStyleBackColor = false;
			// 
			// rbtnWind1
			// 
			this.rbtnWind1.AutoSize = true;
			this.rbtnWind1.BackColor = System.Drawing.Color.Transparent;
			this.rbtnWind1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.rbtnWind1.Location = new System.Drawing.Point(17, 77);
			this.rbtnWind1.Name = "rbtnWind1";
			this.rbtnWind1.Size = new System.Drawing.Size(112, 21);
			this.rbtnWind1.TabIndex = 0;
			this.rbtnWind1.TabStop = true;
			this.rbtnWind1.Text = "Wind Dragon";
			this.rbtnWind1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.rbtnWind1.UseVisualStyleBackColor = false;
			// 
			// rbtnIce1
			// 
			this.rbtnIce1.AutoSize = true;
			this.rbtnIce1.BackColor = System.Drawing.Color.Transparent;
			this.rbtnIce1.ForeColor = System.Drawing.Color.Black;
			this.rbtnIce1.Location = new System.Drawing.Point(17, 50);
			this.rbtnIce1.Name = "rbtnIce1";
			this.rbtnIce1.Size = new System.Drawing.Size(98, 21);
			this.rbtnIce1.TabIndex = 0;
			this.rbtnIce1.TabStop = true;
			this.rbtnIce1.Text = "Ice Dragon";
			this.rbtnIce1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.rbtnIce1.UseVisualStyleBackColor = false;
			// 
			// rbtnFire1
			// 
			this.rbtnFire1.AutoSize = true;
			this.rbtnFire1.BackColor = System.Drawing.Color.Transparent;
			this.rbtnFire1.ForeColor = System.Drawing.Color.Black;
			this.rbtnFire1.Location = new System.Drawing.Point(17, 23);
			this.rbtnFire1.Name = "rbtnFire1";
			this.rbtnFire1.Size = new System.Drawing.Size(104, 21);
			this.rbtnFire1.TabIndex = 0;
			this.rbtnFire1.TabStop = true;
			this.rbtnFire1.Text = "Fire Dragon";
			this.rbtnFire1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.rbtnFire1.UseVisualStyleBackColor = false;
			// 
			// Form_Menu
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ClientSize = new System.Drawing.Size(1304, 508);
			this.Controls.Add(this.lblDragonStats);
			this.Controls.Add(this.lblHeading2);
			this.Controls.Add(this.lblHeading1);
			this.Controls.Add(this.pnlPlayer2);
			this.Controls.Add(this.btnStartgame);
			this.Controls.Add(this.pnlPlayer1);
			this.DoubleBuffered = true;
			this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
			this.Name = "Form_Menu";
			this.Text = "Dragon Battle";
			this.pnlPlayer2.ResumeLayout(false);
			this.pnlPlayer2.PerformLayout();
			this.panel4.ResumeLayout(false);
			this.panel4.PerformLayout();
			this.pnlPlayer1.ResumeLayout(false);
			this.pnlPlayer1.PerformLayout();
			this.panel3.ResumeLayout(false);
			this.panel3.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblDragonStats;
		private System.Windows.Forms.Label lblHeading2;
		private System.Windows.Forms.Label lblHeading1;
		private System.Windows.Forms.Panel pnlPlayer2;
		private System.Windows.Forms.TextBox edtPlayer2dragon;
		private System.Windows.Forms.Label lblDragonListP2;
		private System.Windows.Forms.TextBox edtPlayer2name;
		private System.Windows.Forms.Label lblPlayer2Dragon;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.RadioButton rbtnEarth2;
		private System.Windows.Forms.RadioButton rbtnFire2;
		private System.Windows.Forms.RadioButton rbtnWind2;
		private System.Windows.Forms.RadioButton rbtnIce2;
		private System.Windows.Forms.Label lblPlayer2Name;
		private System.Windows.Forms.Button btnPlayer2Save;
		private System.Windows.Forms.Button btnStartgame;
		private System.Windows.Forms.Panel pnlPlayer1;
		private System.Windows.Forms.TextBox edtPlayer1dragon;
		private System.Windows.Forms.TextBox edtPlayer1name;
		private System.Windows.Forms.Label lblPlayer1Dragon;
		private System.Windows.Forms.Label lblPlayer1Name;
		private System.Windows.Forms.Label lblDraganListP1;
		private System.Windows.Forms.Button btnPlayer1Save;
		private System.Windows.Forms.Panel panel3;
		private System.Windows.Forms.RadioButton rbtnEarth1;
		private System.Windows.Forms.RadioButton rbtnWind1;
		private System.Windows.Forms.RadioButton rbtnIce1;
		private System.Windows.Forms.RadioButton rbtnFire1;
	}
}

