﻿namespace Project
{
	partial class Form_Battle
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblPlayertrun = new System.Windows.Forms.Label();
			this.pnlPlayerTab = new System.Windows.Forms.Panel();
			this.btnReset = new System.Windows.Forms.Button();
			this.lblPlayerstats = new System.Windows.Forms.Label();
			this.btnBlock = new System.Windows.Forms.Button();
			this.btnSpecialAttack = new System.Windows.Forms.Button();
			this.btnAttack = new System.Windows.Forms.Button();
			this.lblOpponent = new System.Windows.Forms.Label();
			this.lblBattlelog = new System.Windows.Forms.Label();
			this.pnlBattle = new System.Windows.Forms.Panel();
			this.richOutput = new System.Windows.Forms.RichTextBox();
			this.pnlOpponent = new System.Windows.Forms.Panel();
			this.lblOpponentstats = new System.Windows.Forms.Label();
			this.pnlPlayerTab.SuspendLayout();
			this.pnlBattle.SuspendLayout();
			this.pnlOpponent.SuspendLayout();
			this.SuspendLayout();
			// 
			// lblPlayertrun
			// 
			this.lblPlayertrun.AutoSize = true;
			this.lblPlayertrun.Location = new System.Drawing.Point(18, 2);
			this.lblPlayertrun.Name = "lblPlayertrun";
			this.lblPlayertrun.Size = new System.Drawing.Size(0, 17);
			this.lblPlayertrun.TabIndex = 7;
			// 
			// pnlPlayerTab
			// 
			this.pnlPlayerTab.BackColor = System.Drawing.Color.Transparent;
			this.pnlPlayerTab.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlPlayerTab.Controls.Add(this.btnReset);
			this.pnlPlayerTab.Controls.Add(this.lblPlayerstats);
			this.pnlPlayerTab.Controls.Add(this.btnBlock);
			this.pnlPlayerTab.Controls.Add(this.btnSpecialAttack);
			this.pnlPlayerTab.Controls.Add(this.btnAttack);
			this.pnlPlayerTab.Location = new System.Drawing.Point(12, 12);
			this.pnlPlayerTab.Name = "pnlPlayerTab";
			this.pnlPlayerTab.Size = new System.Drawing.Size(237, 249);
			this.pnlPlayerTab.TabIndex = 8;
			// 
			// btnReset
			// 
			this.btnReset.Location = new System.Drawing.Point(17, 82);
			this.btnReset.Name = "btnReset";
			this.btnReset.Size = new System.Drawing.Size(203, 161);
			this.btnReset.TabIndex = 13;
			this.btnReset.Text = "Rest";
			this.btnReset.UseVisualStyleBackColor = true;
			this.btnReset.Visible = false;
			this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
			// 
			// lblPlayerstats
			// 
			this.lblPlayerstats.AutoSize = true;
			this.lblPlayerstats.BackColor = System.Drawing.Color.White;
			this.lblPlayerstats.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblPlayerstats.Location = new System.Drawing.Point(53, 44);
			this.lblPlayerstats.Name = "lblPlayerstats";
			this.lblPlayerstats.Size = new System.Drawing.Size(0, 25);
			this.lblPlayerstats.TabIndex = 2;
			// 
			// btnBlock
			// 
			this.btnBlock.Location = new System.Drawing.Point(17, 189);
			this.btnBlock.Name = "btnBlock";
			this.btnBlock.Size = new System.Drawing.Size(203, 41);
			this.btnBlock.TabIndex = 1;
			this.btnBlock.Text = "Block";
			this.btnBlock.UseVisualStyleBackColor = true;
			this.btnBlock.Click += new System.EventHandler(this.btnBlock_Click);
			// 
			// btnSpecialAttack
			// 
			this.btnSpecialAttack.Location = new System.Drawing.Point(17, 142);
			this.btnSpecialAttack.Name = "btnSpecialAttack";
			this.btnSpecialAttack.Size = new System.Drawing.Size(203, 41);
			this.btnSpecialAttack.TabIndex = 1;
			this.btnSpecialAttack.Text = "Special Attack";
			this.btnSpecialAttack.UseVisualStyleBackColor = true;
			this.btnSpecialAttack.Click += new System.EventHandler(this.btnSpecialAttack_Click);
			// 
			// btnAttack
			// 
			this.btnAttack.Location = new System.Drawing.Point(17, 97);
			this.btnAttack.Name = "btnAttack";
			this.btnAttack.Size = new System.Drawing.Size(203, 39);
			this.btnAttack.TabIndex = 1;
			this.btnAttack.Text = "Attack";
			this.btnAttack.UseVisualStyleBackColor = true;
			this.btnAttack.Click += new System.EventHandler(this.btnAttack_Click);
			// 
			// lblOpponent
			// 
			this.lblOpponent.AutoSize = true;
			this.lblOpponent.Location = new System.Drawing.Point(314, 61);
			this.lblOpponent.Name = "lblOpponent";
			this.lblOpponent.Size = new System.Drawing.Size(0, 17);
			this.lblOpponent.TabIndex = 9;
			// 
			// lblBattlelog
			// 
			this.lblBattlelog.AutoSize = true;
			this.lblBattlelog.Location = new System.Drawing.Point(18, 273);
			this.lblBattlelog.Name = "lblBattlelog";
			this.lblBattlelog.Size = new System.Drawing.Size(72, 17);
			this.lblBattlelog.TabIndex = 10;
			this.lblBattlelog.Text = "Battle Log";
			// 
			// pnlBattle
			// 
			this.pnlBattle.BackColor = System.Drawing.Color.Transparent;
			this.pnlBattle.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlBattle.Controls.Add(this.richOutput);
			this.pnlBattle.Location = new System.Drawing.Point(12, 277);
			this.pnlBattle.Name = "pnlBattle";
			this.pnlBattle.Size = new System.Drawing.Size(543, 194);
			this.pnlBattle.TabIndex = 11;
			// 
			// richOutput
			// 
			this.richOutput.Location = new System.Drawing.Point(8, 15);
			this.richOutput.Name = "richOutput";
			this.richOutput.Size = new System.Drawing.Size(513, 165);
			this.richOutput.TabIndex = 0;
			this.richOutput.Text = "";
			// 
			// pnlOpponent
			// 
			this.pnlOpponent.BackColor = System.Drawing.Color.Transparent;
			this.pnlOpponent.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.pnlOpponent.Controls.Add(this.lblOpponentstats);
			this.pnlOpponent.Location = new System.Drawing.Point(283, 71);
			this.pnlOpponent.Name = "pnlOpponent";
			this.pnlOpponent.Size = new System.Drawing.Size(272, 143);
			this.pnlOpponent.TabIndex = 12;
			// 
			// lblOpponentstats
			// 
			this.lblOpponentstats.AutoSize = true;
			this.lblOpponentstats.BackColor = System.Drawing.Color.White;
			this.lblOpponentstats.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblOpponentstats.Location = new System.Drawing.Point(12, 29);
			this.lblOpponentstats.Name = "lblOpponentstats";
			this.lblOpponentstats.Size = new System.Drawing.Size(0, 20);
			this.lblOpponentstats.TabIndex = 2;
			// 
			// Form_Battle
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.SystemColors.ActiveCaption;
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
			this.ClientSize = new System.Drawing.Size(597, 492);
			this.Controls.Add(this.lblPlayertrun);
			this.Controls.Add(this.pnlPlayerTab);
			this.Controls.Add(this.lblOpponent);
			this.Controls.Add(this.lblBattlelog);
			this.Controls.Add(this.pnlBattle);
			this.Controls.Add(this.pnlOpponent);
			this.DoubleBuffered = true;
			this.Name = "Form_Battle";
			this.pnlPlayerTab.ResumeLayout(false);
			this.pnlPlayerTab.PerformLayout();
			this.pnlBattle.ResumeLayout(false);
			this.pnlOpponent.ResumeLayout(false);
			this.pnlOpponent.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblPlayertrun;
		private System.Windows.Forms.Panel pnlPlayerTab;
		private System.Windows.Forms.Label lblPlayerstats;
		private System.Windows.Forms.Button btnBlock;
		private System.Windows.Forms.Button btnSpecialAttack;
		private System.Windows.Forms.Button btnAttack;
		private System.Windows.Forms.Label lblOpponent;
		private System.Windows.Forms.Label lblBattlelog;
		private System.Windows.Forms.Panel pnlBattle;
		private System.Windows.Forms.RichTextBox richOutput;
		private System.Windows.Forms.Panel pnlOpponent;
		private System.Windows.Forms.Label lblOpponentstats;
		private System.Windows.Forms.Button btnReset;
	}
}