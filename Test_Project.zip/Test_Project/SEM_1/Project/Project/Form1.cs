﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Project
{
	public partial class Form_Menu : Form
	{
		const string FIRE_DRAG_TYPE = "Fire Dragon";  //{
		const int FIRE_DRAG_HP = 20;
		const int FIRE_DRAG_AD = 5;
		const int FIRE_DRAG_SA = 12;
		const int FIRE_DRAG_BD = 4;

		const string ICE_DRAG_TYPE = "Ice Dragon";
		const int ICE_DRAG_HP = 30;
		const int ICE_DRAG_AD = 4;
		const int ICE_DRAG_SA = 9;
		const int ICE_DRAG_BD = 5;

		const string WIND_DRAG_TYPE = "Wind Dragon";            // Assigning the const vaules for each type dragon.
		const int WIND_DRAG_HP = 40;
		const int WIND_DRAG_AD = 3;
		const int WIND_DRAG_SA = 7;
		const int WIND_DRAG_BD = 5;

		const string EARTH_DRAG_TYPE = "Earth Dragon";
		const int EARTH_DRAG_HP = 50;
		const int EARTH_DRAG_AD = 2;
		const int EARTH_DRAG_SA = 5;
		const int EARTH_DRAG_BD = 6;            //}
		public static int player1;
		public static int player2;
		bool saveOne;
		bool saveTwo;
		// The player 1 array.
		public static string[] player1Information = new string[3];
		// The player 2 array.
		public static string[] player2Information = new string[3];
		// The player 1 dargon stats array.
		public static int[] dragon1Infomation = new int[4];
		// The player 2 dargon stats array.
		public static int[] dragon2Infomation = new int[4];
		public static Random roll = new Random();
		public Form_Menu()
		{
			InitializeComponent();
			btnStartgame.Enabled = false;
		}
		public static int Random_roll()
		{  // Creating random roll.
			return roll.Next(1, 7);
		}
		public static int take_Initiative()
		{
			player1 = Random_roll();
			player2 = Random_roll();
			// Checking which player rolls higher.
			while (player1 == player2)
			{
				player1 = Random_roll();
				player2 = Random_roll();
			}
				if (player1 > player2)
				{
					return 1;

				}
				else
				{
					return 2;
				}
			
		}
		private void save_Vaules()
		{
			string player1Name;
			string player1Dragon;
			string player2Name;
			string player2Dragon;
			player1Name = edtPlayer1name.Text;
			// saving the player 1 name. "Astrid"	
			player1Dragon = edtPlayer1dragon.Text;
			//saving the player 1 dragon name. "Stormfly"
			player2Name = edtPlayer2name.Text;
			// Saving player 2 name."Hiccup"
			player2Dragon = edtPlayer2dragon.Text;
			// Saving player 2 dragon name. "Toothless"
			
			player1Information[0] = player1Name;
			player1Information[1] = player1Dragon;

			// if the dragon type is checked add the stats to Dragon1infomation. (Player 1)
			if (rbtnFire1.Checked)
			{  // Assigning the fire dargons stats.
				dragon1Infomation[0] = FIRE_DRAG_HP;
				dragon1Infomation[1] = FIRE_DRAG_AD;
				dragon1Infomation[2] = FIRE_DRAG_SA;
				dragon1Infomation[3] = FIRE_DRAG_BD;
				player1Information[2] = FIRE_DRAG_TYPE;
			}
			if (rbtnIce1.Checked)
			{ // Assigning the ice dargons stats.
				dragon1Infomation[0] = ICE_DRAG_HP;
				dragon1Infomation[1] = ICE_DRAG_AD;
				dragon1Infomation[2] = ICE_DRAG_SA;
				dragon1Infomation[3] = ICE_DRAG_BD;
				player1Information[2] = ICE_DRAG_TYPE;
			}
			if (rbtnWind1.Checked)
			{   // Assigning the wind dargons stats.
				dragon1Infomation[0] = WIND_DRAG_HP;
				dragon1Infomation[1] = WIND_DRAG_AD;
				dragon1Infomation[2] = WIND_DRAG_SA;
				dragon1Infomation[3] = WIND_DRAG_BD;
				player1Information[2] = WIND_DRAG_TYPE;
			}
			if (rbtnEarth1.Checked)
			{// Assigning the earth dargons stats.
				dragon1Infomation[0] = EARTH_DRAG_HP;
				dragon1Infomation[1] = EARTH_DRAG_AD;
				dragon1Infomation[2] = EARTH_DRAG_SA;
				dragon1Infomation[3] = EARTH_DRAG_BD;
				player1Information[2] = EARTH_DRAG_TYPE;
			}

			player2Information[0] = player2Name;
			player2Information[1] = player2Dragon;
			// if the dragon type is checked add the stats to Dragon1infomation. (Player 2)
			if (rbtnFire2.Checked)
			{// Assigning the fire dargons stats.
				dragon2Infomation[0] = FIRE_DRAG_HP;
				dragon2Infomation[1] = FIRE_DRAG_AD;
				dragon2Infomation[2] = FIRE_DRAG_SA;
				dragon2Infomation[3] = FIRE_DRAG_BD;
				player2Information[2] = FIRE_DRAG_TYPE;
			}
			if (rbtnIce2.Checked)
			{// Assigning the ice dargons stats.
				dragon2Infomation[0] = ICE_DRAG_HP;
				dragon2Infomation[1] = ICE_DRAG_AD;
				dragon2Infomation[2] = ICE_DRAG_SA;
				dragon2Infomation[3] = ICE_DRAG_BD;
				player2Information[2] = ICE_DRAG_TYPE;
			}
			if (rbtnWind2.Checked)
			{ // Assigning the wind dargons stats.
				dragon2Infomation[0] = WIND_DRAG_HP;
				dragon2Infomation[1] = WIND_DRAG_AD;
				dragon2Infomation[2] = WIND_DRAG_SA;
				dragon2Infomation[3] = WIND_DRAG_BD;
				player2Information[2] = WIND_DRAG_TYPE;
			}
			if (rbtnEarth2.Checked)
			{  // Assigning the earth dargons stats.
				dragon2Infomation[0] = EARTH_DRAG_HP;
				dragon2Infomation[1] = EARTH_DRAG_AD;
				dragon2Infomation[2] = EARTH_DRAG_SA;
				dragon2Infomation[3] = EARTH_DRAG_BD;
				player2Information[2] = EARTH_DRAG_TYPE; 
			}

			
		}

		private void btnPlayer1Save_Click(object sender, EventArgs e)
		{
			saveOne = true;                                                 // In order for the button check method to work(method: buttonSaveCheck).
			save_Vaules();                                                  // Adds the vaules for the user to the arrays.
			btnPlayer1Save.ForeColor = Color.DarkGreen;                     // This colour change indicates that the button has been clicked.
			buttonSaveCheck();
		}

		private void btnPlayer2Save_Click(object sender, EventArgs e)
		{
			saveTwo = true;                                         // In order for the button check method to work(method: buttonSaveCheck).
			save_Vaules();                                           // Adds the vaules for the user to the arrays.
			btnPlayer2Save.ForeColor = Color.DarkGreen;             // This colour change indicates that the button has been clicked.
			buttonSaveCheck();
		}

		private void btnStartgame_Click(object sender, EventArgs e)
		{ // Once this is clicked the players will swtich to the battle form.
			nextForm();
			take_Initiative();

		}
		private void buttonSaveCheck()
		{  // This method is to check that the two save buttons have been clicked.
			if (saveOne == true & saveTwo == true)
			{  // enables the user to move ro the next form.
				btnStartgame.Enabled = true;
			}
		}
		 public static void onLoad()
		{
			Form_Battle.player1Details[0] = player1Information[0];
			Form_Battle.player1Details[1] = player1Information[1];
			Form_Battle.player1Details[2] = player1Information[2];
			Form_Battle.player2Details[0] = player2Information[0];
			Form_Battle.player2Details[1] = player2Information[1];
			Form_Battle.player2Details[2] = player2Information[2];
			Form_Battle.dragon1Details[0] = dragon1Infomation[0];
			Form_Battle.dragon1Details[1] = dragon1Infomation[1];
			Form_Battle.dragon1Details[2] = dragon1Infomation[2];
			Form_Battle.dragon1Details[3] = dragon1Infomation[3];
			Form_Battle.dragon2Details[0] = dragon2Infomation[0];
			Form_Battle.dragon2Details[1] = dragon2Infomation[1];
			Form_Battle.dragon2Details[2] = dragon2Infomation[2];
			Form_Battle.dragon2Details[1] = dragon2Infomation[3];

		}
		private void nextForm()
		{
			Form_Battle next = new Form_Battle();
			next.Show();
			this.Hide();
		}

		private void lblDragonStats_Click(object sender, EventArgs e)
		{

		}
	}
}
