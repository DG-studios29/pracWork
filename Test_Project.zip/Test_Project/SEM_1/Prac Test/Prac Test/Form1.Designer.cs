﻿namespace Prac_Test
{
	partial class EncryptAndDecrypt
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.btnEncrypt = new System.Windows.Forms.Button();
			this.btnDencrypt = new System.Windows.Forms.Button();
			this.lblUnencrypted = new System.Windows.Forms.Label();
			this.edtUnencrypted = new System.Windows.Forms.TextBox();
			this.lblKey = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.lblencrypted = new System.Windows.Forms.Label();
			this.edtKey = new System.Windows.Forms.TextBox();
			this.edtencrypt = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// btnEncrypt
			// 
			this.btnEncrypt.Location = new System.Drawing.Point(238, 342);
			this.btnEncrypt.Name = "btnEncrypt";
			this.btnEncrypt.Size = new System.Drawing.Size(142, 56);
			this.btnEncrypt.TabIndex = 0;
			this.btnEncrypt.Text = "Encrypt";
			this.btnEncrypt.UseVisualStyleBackColor = true;
			this.btnEncrypt.Click += new System.EventHandler(this.btnEncrypt_Click);
			// 
			// btnDencrypt
			// 
			this.btnDencrypt.Location = new System.Drawing.Point(404, 342);
			this.btnDencrypt.Name = "btnDencrypt";
			this.btnDencrypt.Size = new System.Drawing.Size(142, 56);
			this.btnDencrypt.TabIndex = 0;
			this.btnDencrypt.Text = "Dencrypt";
			this.btnDencrypt.UseVisualStyleBackColor = true;
			this.btnDencrypt.Click += new System.EventHandler(this.btnDencrypt_Click);
			// 
			// lblUnencrypted
			// 
			this.lblUnencrypted.AutoSize = true;
			this.lblUnencrypted.Location = new System.Drawing.Point(235, 95);
			this.lblUnencrypted.Name = "lblUnencrypted";
			this.lblUnencrypted.Size = new System.Drawing.Size(130, 17);
			this.lblUnencrypted.TabIndex = 1;
			this.lblUnencrypted.Text = "Unencrypted String";
			// 
			// edtUnencrypted
			// 
			this.edtUnencrypted.Location = new System.Drawing.Point(238, 128);
			this.edtUnencrypted.Name = "edtUnencrypted";
			this.edtUnencrypted.Size = new System.Drawing.Size(308, 22);
			this.edtUnencrypted.TabIndex = 2;
			// 
			// lblKey
			// 
			this.lblKey.AutoSize = true;
			this.lblKey.Location = new System.Drawing.Point(235, 167);
			this.lblKey.Name = "lblKey";
			this.lblKey.Size = new System.Drawing.Size(32, 17);
			this.lblKey.TabIndex = 1;
			this.lblKey.Text = "Key";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(235, 234);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(46, 17);
			this.label3.TabIndex = 1;
			this.label3.Text = "label1";
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(238, 195);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(308, 22);
			this.textBox2.TabIndex = 2;
			// 
			// lblencrypted
			// 
			this.lblencrypted.AutoSize = true;
			this.lblencrypted.Location = new System.Drawing.Point(235, 234);
			this.lblencrypted.Name = "lblencrypted";
			this.lblencrypted.Size = new System.Drawing.Size(113, 17);
			this.lblencrypted.TabIndex = 1;
			this.lblencrypted.Text = "Encrypted String";
			// 
			// edtKey
			// 
			this.edtKey.Location = new System.Drawing.Point(238, 195);
			this.edtKey.Name = "edtKey";
			this.edtKey.Size = new System.Drawing.Size(308, 22);
			this.edtKey.TabIndex = 2;
			// 
			// edtencrypt
			// 
			this.edtencrypt.Location = new System.Drawing.Point(238, 267);
			this.edtencrypt.Name = "edtencrypt";
			this.edtencrypt.Size = new System.Drawing.Size(308, 22);
			this.edtencrypt.TabIndex = 2;
			// 
			// EncryptAndDecrypt
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(814, 504);
			this.Controls.Add(this.edtKey);
			this.Controls.Add(this.textBox2);
			this.Controls.Add(this.lblencrypted);
			this.Controls.Add(this.edtencrypt);
			this.Controls.Add(this.edtUnencrypted);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.lblKey);
			this.Controls.Add(this.lblUnencrypted);
			this.Controls.Add(this.btnDencrypt);
			this.Controls.Add(this.btnEncrypt);
			this.Name = "EncryptAndDecrypt";
			this.Text = "Encrypt and Decrypt";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btnEncrypt;
		private System.Windows.Forms.Button btnDencrypt;
		private System.Windows.Forms.Label lblUnencrypted;
		private System.Windows.Forms.TextBox edtUnencrypted;
		private System.Windows.Forms.Label lblKey;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox2;
		private System.Windows.Forms.Label lblencrypted;
		private System.Windows.Forms.TextBox edtKey;
		private System.Windows.Forms.TextBox edtencrypt;
	}
}

