﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Prac_Test
{
	public partial class EncryptAndDecrypt : Form
	{
		char[] dencrypted;
		char[] encrypted;
		

		public EncryptAndDecrypt()
		{
			InitializeComponent();
			
		}

		private void btnEncrypt_Click(object sender, EventArgs e)
		{
			dencrypted = edtUnencrypted.Text.ToCharArray();
			encrypted = new char[dencrypted.Length];
			int Key = Convert.ToInt32(edtKey.Text);
			string builtEncryptedWord = "";

			for (int i = 0; i < dencrypted.Length; i++)
			{
				encrypted[i] = (char)((int)dencrypted[i] + Key);
				builtEncryptedWord += encrypted[i];
			}
			edtencrypt.Text = builtEncryptedWord;



		}

		private void btnDencrypt_Click(object sender, EventArgs e)
		{


			encrypted = edtencrypt.Text.ToCharArray();
			dencrypted = new char[encrypted.Length];
			int Key = Convert.ToInt32(edtKey.Text);
			string builtDencryptedWord = "";

			for (int i = 0; i < encrypted.Length; i++)
			{
				dencrypted[i] = (char)((int)encrypted[i] - Key);
				builtDencryptedWord += dencrypted[i];
			}
			edtUnencrypted.Text = builtDencryptedWord;



		}
	}
}