﻿namespace Dhillan_Gopal_GADE5111_Assignment_1
{
	partial class frmDargon_Menu
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDargon_Menu));
			this.groboxPlayer1 = new System.Windows.Forms.GroupBox();
			this.btnPlayer1Save = new System.Windows.Forms.Button();
			this.groboxPlayer1DragonList = new System.Windows.Forms.GroupBox();
			this.rbtnPlayer1Wind = new System.Windows.Forms.RadioButton();
			this.rbtnPlayer1Earth = new System.Windows.Forms.RadioButton();
			this.rbtnPlayer1Ice = new System.Windows.Forms.RadioButton();
			this.rbtnPlayer1Fire = new System.Windows.Forms.RadioButton();
			this.edtPlayer1Dragon = new System.Windows.Forms.TextBox();
			this.edtPlayer1Name = new System.Windows.Forms.TextBox();
			this.lblPlayer1Dargon = new System.Windows.Forms.Label();
			this.lblPlayer1Name = new System.Windows.Forms.Label();
			this.groboxPlayer2 = new System.Windows.Forms.GroupBox();
			this.btnPlayer2Save = new System.Windows.Forms.Button();
			this.groboxPlayer2DragonList = new System.Windows.Forms.GroupBox();
			this.rbtnPlayer2Wind = new System.Windows.Forms.RadioButton();
			this.rbtnPlayer2Earth = new System.Windows.Forms.RadioButton();
			this.rbtnPlayer2Ice = new System.Windows.Forms.RadioButton();
			this.rbtnPlayer2Fire = new System.Windows.Forms.RadioButton();
			this.edtPlayer2Dragon = new System.Windows.Forms.TextBox();
			this.edtPlayer2Name = new System.Windows.Forms.TextBox();
			this.lblPlayer2Dragon = new System.Windows.Forms.Label();
			this.lblPlayer2Name = new System.Windows.Forms.Label();
			this.btnGameStart = new System.Windows.Forms.Button();
			this.lblDragonStats = new System.Windows.Forms.Label();
			this.groboxPlayer1.SuspendLayout();
			this.groboxPlayer1DragonList.SuspendLayout();
			this.groboxPlayer2.SuspendLayout();
			this.groboxPlayer2DragonList.SuspendLayout();
			this.SuspendLayout();
			// 
			// groboxPlayer1
			// 
			this.groboxPlayer1.Controls.Add(this.btnPlayer1Save);
			this.groboxPlayer1.Controls.Add(this.groboxPlayer1DragonList);
			this.groboxPlayer1.Controls.Add(this.edtPlayer1Dragon);
			this.groboxPlayer1.Controls.Add(this.edtPlayer1Name);
			this.groboxPlayer1.Controls.Add(this.lblPlayer1Dargon);
			this.groboxPlayer1.Controls.Add(this.lblPlayer1Name);
			this.groboxPlayer1.Location = new System.Drawing.Point(25, 34);
			this.groboxPlayer1.Name = "groboxPlayer1";
			this.groboxPlayer1.Size = new System.Drawing.Size(477, 398);
			this.groboxPlayer1.TabIndex = 0;
			this.groboxPlayer1.TabStop = false;
			this.groboxPlayer1.Text = "Player 1";
			// 
			// btnPlayer1Save
			// 
			this.btnPlayer1Save.Location = new System.Drawing.Point(21, 310);
			this.btnPlayer1Save.Name = "btnPlayer1Save";
			this.btnPlayer1Save.Size = new System.Drawing.Size(426, 40);
			this.btnPlayer1Save.TabIndex = 3;
			this.btnPlayer1Save.Text = "Save";
			this.btnPlayer1Save.UseVisualStyleBackColor = true;
			this.btnPlayer1Save.Click += new System.EventHandler(this.btnPlayer1Save_Click);
			// 
			// groboxPlayer1DragonList
			// 
			this.groboxPlayer1DragonList.Controls.Add(this.rbtnPlayer1Wind);
			this.groboxPlayer1DragonList.Controls.Add(this.rbtnPlayer1Earth);
			this.groboxPlayer1DragonList.Controls.Add(this.rbtnPlayer1Ice);
			this.groboxPlayer1DragonList.Controls.Add(this.rbtnPlayer1Fire);
			this.groboxPlayer1DragonList.Location = new System.Drawing.Point(21, 146);
			this.groboxPlayer1DragonList.Name = "groboxPlayer1DragonList";
			this.groboxPlayer1DragonList.Size = new System.Drawing.Size(426, 158);
			this.groboxPlayer1DragonList.TabIndex = 2;
			this.groboxPlayer1DragonList.TabStop = false;
			this.groboxPlayer1DragonList.Text = "Dragon Type";
			// 
			// rbtnPlayer1Wind
			// 
			this.rbtnPlayer1Wind.AutoSize = true;
			this.rbtnPlayer1Wind.Location = new System.Drawing.Point(18, 118);
			this.rbtnPlayer1Wind.Name = "rbtnPlayer1Wind";
			this.rbtnPlayer1Wind.Size = new System.Drawing.Size(112, 21);
			this.rbtnPlayer1Wind.TabIndex = 0;
			this.rbtnPlayer1Wind.TabStop = true;
			this.rbtnPlayer1Wind.Text = "Wind Dragon";
			this.rbtnPlayer1Wind.UseVisualStyleBackColor = true;
			// 
			// rbtnPlayer1Earth
			// 
			this.rbtnPlayer1Earth.AutoSize = true;
			this.rbtnPlayer1Earth.Location = new System.Drawing.Point(18, 91);
			this.rbtnPlayer1Earth.Name = "rbtnPlayer1Earth";
			this.rbtnPlayer1Earth.Size = new System.Drawing.Size(114, 21);
			this.rbtnPlayer1Earth.TabIndex = 0;
			this.rbtnPlayer1Earth.TabStop = true;
			this.rbtnPlayer1Earth.Text = "Earth Dragon";
			this.rbtnPlayer1Earth.UseVisualStyleBackColor = true;
			// 
			// rbtnPlayer1Ice
			// 
			this.rbtnPlayer1Ice.AutoSize = true;
			this.rbtnPlayer1Ice.Location = new System.Drawing.Point(18, 64);
			this.rbtnPlayer1Ice.Name = "rbtnPlayer1Ice";
			this.rbtnPlayer1Ice.Size = new System.Drawing.Size(98, 21);
			this.rbtnPlayer1Ice.TabIndex = 0;
			this.rbtnPlayer1Ice.TabStop = true;
			this.rbtnPlayer1Ice.Text = "Ice Dragon";
			this.rbtnPlayer1Ice.UseVisualStyleBackColor = true;
			// 
			// rbtnPlayer1Fire
			// 
			this.rbtnPlayer1Fire.AutoSize = true;
			this.rbtnPlayer1Fire.Location = new System.Drawing.Point(18, 37);
			this.rbtnPlayer1Fire.Name = "rbtnPlayer1Fire";
			this.rbtnPlayer1Fire.Size = new System.Drawing.Size(104, 21);
			this.rbtnPlayer1Fire.TabIndex = 0;
			this.rbtnPlayer1Fire.TabStop = true;
			this.rbtnPlayer1Fire.Text = "Fire Dragon";
			this.rbtnPlayer1Fire.UseVisualStyleBackColor = true;
			// 
			// edtPlayer1Dragon
			// 
			this.edtPlayer1Dragon.Location = new System.Drawing.Point(124, 84);
			this.edtPlayer1Dragon.Name = "edtPlayer1Dragon";
			this.edtPlayer1Dragon.Size = new System.Drawing.Size(243, 22);
			this.edtPlayer1Dragon.TabIndex = 1;
			// 
			// edtPlayer1Name
			// 
			this.edtPlayer1Name.Location = new System.Drawing.Point(124, 43);
			this.edtPlayer1Name.Name = "edtPlayer1Name";
			this.edtPlayer1Name.Size = new System.Drawing.Size(243, 22);
			this.edtPlayer1Name.TabIndex = 1;
			// 
			// lblPlayer1Dargon
			// 
			this.lblPlayer1Dargon.AutoSize = true;
			this.lblPlayer1Dargon.Location = new System.Drawing.Point(18, 87);
			this.lblPlayer1Dargon.Name = "lblPlayer1Dargon";
			this.lblPlayer1Dargon.Size = new System.Drawing.Size(100, 17);
			this.lblPlayer1Dargon.TabIndex = 0;
			this.lblPlayer1Dargon.Text = "Dargon Name:";
			// 
			// lblPlayer1Name
			// 
			this.lblPlayer1Name.AutoSize = true;
			this.lblPlayer1Name.Location = new System.Drawing.Point(18, 46);
			this.lblPlayer1Name.Name = "lblPlayer1Name";
			this.lblPlayer1Name.Size = new System.Drawing.Size(93, 17);
			this.lblPlayer1Name.TabIndex = 0;
			this.lblPlayer1Name.Text = "Player Name:";
			// 
			// groboxPlayer2
			// 
			this.groboxPlayer2.Controls.Add(this.btnPlayer2Save);
			this.groboxPlayer2.Controls.Add(this.groboxPlayer2DragonList);
			this.groboxPlayer2.Controls.Add(this.edtPlayer2Dragon);
			this.groboxPlayer2.Controls.Add(this.edtPlayer2Name);
			this.groboxPlayer2.Controls.Add(this.lblPlayer2Dragon);
			this.groboxPlayer2.Controls.Add(this.lblPlayer2Name);
			this.groboxPlayer2.Location = new System.Drawing.Point(548, 34);
			this.groboxPlayer2.Name = "groboxPlayer2";
			this.groboxPlayer2.Size = new System.Drawing.Size(477, 398);
			this.groboxPlayer2.TabIndex = 0;
			this.groboxPlayer2.TabStop = false;
			this.groboxPlayer2.Text = "Player 2";
			// 
			// btnPlayer2Save
			// 
			this.btnPlayer2Save.Location = new System.Drawing.Point(21, 310);
			this.btnPlayer2Save.Name = "btnPlayer2Save";
			this.btnPlayer2Save.Size = new System.Drawing.Size(426, 40);
			this.btnPlayer2Save.TabIndex = 3;
			this.btnPlayer2Save.Text = "Save";
			this.btnPlayer2Save.UseVisualStyleBackColor = true;
			this.btnPlayer2Save.Click += new System.EventHandler(this.btnPlayer2Save_Click);
			// 
			// groboxPlayer2DragonList
			// 
			this.groboxPlayer2DragonList.Controls.Add(this.rbtnPlayer2Wind);
			this.groboxPlayer2DragonList.Controls.Add(this.rbtnPlayer2Earth);
			this.groboxPlayer2DragonList.Controls.Add(this.rbtnPlayer2Ice);
			this.groboxPlayer2DragonList.Controls.Add(this.rbtnPlayer2Fire);
			this.groboxPlayer2DragonList.Location = new System.Drawing.Point(21, 146);
			this.groboxPlayer2DragonList.Name = "groboxPlayer2DragonList";
			this.groboxPlayer2DragonList.Size = new System.Drawing.Size(426, 158);
			this.groboxPlayer2DragonList.TabIndex = 2;
			this.groboxPlayer2DragonList.TabStop = false;
			this.groboxPlayer2DragonList.Text = "Dragon Type";
			// 
			// rbtnPlayer2Wind
			// 
			this.rbtnPlayer2Wind.AutoSize = true;
			this.rbtnPlayer2Wind.Location = new System.Drawing.Point(18, 118);
			this.rbtnPlayer2Wind.Name = "rbtnPlayer2Wind";
			this.rbtnPlayer2Wind.Size = new System.Drawing.Size(112, 21);
			this.rbtnPlayer2Wind.TabIndex = 0;
			this.rbtnPlayer2Wind.TabStop = true;
			this.rbtnPlayer2Wind.Text = "Wind Dragon";
			this.rbtnPlayer2Wind.UseVisualStyleBackColor = true;
			// 
			// rbtnPlayer2Earth
			// 
			this.rbtnPlayer2Earth.AutoSize = true;
			this.rbtnPlayer2Earth.Location = new System.Drawing.Point(18, 91);
			this.rbtnPlayer2Earth.Name = "rbtnPlayer2Earth";
			this.rbtnPlayer2Earth.Size = new System.Drawing.Size(114, 21);
			this.rbtnPlayer2Earth.TabIndex = 0;
			this.rbtnPlayer2Earth.TabStop = true;
			this.rbtnPlayer2Earth.Text = "Earth Dragon";
			this.rbtnPlayer2Earth.UseVisualStyleBackColor = true;
			// 
			// rbtnPlayer2Ice
			// 
			this.rbtnPlayer2Ice.AutoSize = true;
			this.rbtnPlayer2Ice.Location = new System.Drawing.Point(18, 64);
			this.rbtnPlayer2Ice.Name = "rbtnPlayer2Ice";
			this.rbtnPlayer2Ice.Size = new System.Drawing.Size(98, 21);
			this.rbtnPlayer2Ice.TabIndex = 0;
			this.rbtnPlayer2Ice.TabStop = true;
			this.rbtnPlayer2Ice.Text = "Ice Dragon";
			this.rbtnPlayer2Ice.UseVisualStyleBackColor = true;
			// 
			// rbtnPlayer2Fire
			// 
			this.rbtnPlayer2Fire.AutoSize = true;
			this.rbtnPlayer2Fire.Location = new System.Drawing.Point(18, 37);
			this.rbtnPlayer2Fire.Name = "rbtnPlayer2Fire";
			this.rbtnPlayer2Fire.Size = new System.Drawing.Size(104, 21);
			this.rbtnPlayer2Fire.TabIndex = 0;
			this.rbtnPlayer2Fire.TabStop = true;
			this.rbtnPlayer2Fire.Text = "Fire Dragon";
			this.rbtnPlayer2Fire.UseVisualStyleBackColor = true;
			// 
			// edtPlayer2Dragon
			// 
			this.edtPlayer2Dragon.Location = new System.Drawing.Point(124, 84);
			this.edtPlayer2Dragon.Name = "edtPlayer2Dragon";
			this.edtPlayer2Dragon.Size = new System.Drawing.Size(243, 22);
			this.edtPlayer2Dragon.TabIndex = 1;
			// 
			// edtPlayer2Name
			// 
			this.edtPlayer2Name.Location = new System.Drawing.Point(124, 43);
			this.edtPlayer2Name.Name = "edtPlayer2Name";
			this.edtPlayer2Name.Size = new System.Drawing.Size(243, 22);
			this.edtPlayer2Name.TabIndex = 1;
			// 
			// lblPlayer2Dragon
			// 
			this.lblPlayer2Dragon.AutoSize = true;
			this.lblPlayer2Dragon.Location = new System.Drawing.Point(18, 87);
			this.lblPlayer2Dragon.Name = "lblPlayer2Dragon";
			this.lblPlayer2Dragon.Size = new System.Drawing.Size(100, 17);
			this.lblPlayer2Dragon.TabIndex = 0;
			this.lblPlayer2Dragon.Text = "Dargon Name:";
			// 
			// lblPlayer2Name
			// 
			this.lblPlayer2Name.AutoSize = true;
			this.lblPlayer2Name.Location = new System.Drawing.Point(18, 46);
			this.lblPlayer2Name.Name = "lblPlayer2Name";
			this.lblPlayer2Name.Size = new System.Drawing.Size(93, 17);
			this.lblPlayer2Name.TabIndex = 0;
			this.lblPlayer2Name.Text = "Player Name:";
			// 
			// btnGameStart
			// 
			this.btnGameStart.Location = new System.Drawing.Point(25, 453);
			this.btnGameStart.Name = "btnGameStart";
			this.btnGameStart.Size = new System.Drawing.Size(1000, 52);
			this.btnGameStart.TabIndex = 1;
			this.btnGameStart.Text = "Start Game";
			this.btnGameStart.UseVisualStyleBackColor = true;
			this.btnGameStart.Click += new System.EventHandler(this.btnGameStart_Click);
			// 
			// lblDragonStats
			// 
			this.lblDragonStats.AutoSize = true;
			this.lblDragonStats.Location = new System.Drawing.Point(1062, 46);
			this.lblDragonStats.Name = "lblDragonStats";
			this.lblDragonStats.Size = new System.Drawing.Size(209, 425);
			this.lblDragonStats.TabIndex = 2;
			this.lblDragonStats.Text = resources.GetString("lblDragonStats.Text");
			// 
			// frmDargon_Menu
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1337, 536);
			this.Controls.Add(this.lblDragonStats);
			this.Controls.Add(this.btnGameStart);
			this.Controls.Add(this.groboxPlayer2);
			this.Controls.Add(this.groboxPlayer1);
			this.Name = "frmDargon_Menu";
			this.Text = "Dargon Battle!";
			this.groboxPlayer1.ResumeLayout(false);
			this.groboxPlayer1.PerformLayout();
			this.groboxPlayer1DragonList.ResumeLayout(false);
			this.groboxPlayer1DragonList.PerformLayout();
			this.groboxPlayer2.ResumeLayout(false);
			this.groboxPlayer2.PerformLayout();
			this.groboxPlayer2DragonList.ResumeLayout(false);
			this.groboxPlayer2DragonList.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.GroupBox groboxPlayer1;
		private System.Windows.Forms.Button btnPlayer1Save;
		private System.Windows.Forms.GroupBox groboxPlayer1DragonList;
		private System.Windows.Forms.RadioButton rbtnPlayer1Wind;
		private System.Windows.Forms.RadioButton rbtnPlayer1Earth;
		private System.Windows.Forms.RadioButton rbtnPlayer1Ice;
		private System.Windows.Forms.RadioButton rbtnPlayer1Fire;
		private System.Windows.Forms.TextBox edtPlayer1Dragon;
		private System.Windows.Forms.TextBox edtPlayer1Name;
		private System.Windows.Forms.Label lblPlayer1Dargon;
		private System.Windows.Forms.Label lblPlayer1Name;
		private System.Windows.Forms.GroupBox groboxPlayer2;
		private System.Windows.Forms.Button btnPlayer2Save;
		private System.Windows.Forms.GroupBox groboxPlayer2DragonList;
		private System.Windows.Forms.RadioButton rbtnPlayer2Wind;
		private System.Windows.Forms.RadioButton rbtnPlayer2Earth;
		private System.Windows.Forms.RadioButton rbtnPlayer2Ice;
		private System.Windows.Forms.RadioButton rbtnPlayer2Fire;
		private System.Windows.Forms.TextBox edtPlayer2Dragon;
		private System.Windows.Forms.TextBox edtPlayer2Name;
		private System.Windows.Forms.Label lblPlayer2Dragon;
		private System.Windows.Forms.Label lblPlayer2Name;
		private System.Windows.Forms.Button btnGameStart;
		private System.Windows.Forms.Label lblDragonStats;
	}
}

