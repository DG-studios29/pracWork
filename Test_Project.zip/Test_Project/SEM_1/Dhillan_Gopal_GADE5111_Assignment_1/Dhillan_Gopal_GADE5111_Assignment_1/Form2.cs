﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dhillan_Gopal_GADE5111_Assignment_1
{
	public partial class FrmDragonBattle : Form
	{   // Declaring all variables.
		public static string[] player1Details = new string[3];
		public static string[] player2Details = new string[3];
		public static int[] dragon1Details = new int[4];
		public static int[] dragon2Details = new int[4];
		int block1;
		int attack1;
		int specialAttack1;
		int block2;
		int attack2;
		int specialAttack2;
		bool playerTurn;
		int dragonHP1;
		int dragonTired = 0;
		int dragonHP2;
		string player1;
		string dragonname1;
		string player2;
		string dragonname2;
		string dragontype1;
		string dragontype2;
		bool block1Actived = false;
		bool block2Actived = false;
		bool turnTaken1 = false;
		bool turnTaken2 = false;
		public FrmDragonBattle()
		{
			InitializeComponent();
			// Loads all the details from the arrays.
			onLoad();
			
		}
		private void onLoad()
		{
			frmDargon_Menu.onLoad();
			for (int i = 0; i < player1Details.Length; i++)
			{   // Assigning the variables from player1Information array to the variables in this form.                                                                      
				player1 = player1Details[0];
				dragonname1 = player1Details[1];
				dragontype1 = player1Details[2];
			}

			for (int i = 0; i < dragon1Details.Length; i++)
			{   // Assigning the variables from dragon1Infomation array to the variables in this form.                                                                    
				dragonHP1 = dragon1Details[0];
				attack1 = dragon1Details[1];
				specialAttack1 = dragon1Details[2];
				block1 = dragon1Details[3];


			}
			for (int i = 0; i < player2Details.Length; i++)
			{   // Assigning the variables from player2Information array to the variables in this form.                                                                      
				player2 = player2Details[0];
				dragontype2 = player2Details[2];
				dragonname2 = player2Details[1];
			}

			for (int i = 0; i < dragon1Details.Length; i++)
			{   // Assigning the variables from dragon1Infomation array to the variables in this form.                                                                    
				dragonHP2 = dragon2Details[0];
				attack2 = dragon2Details[1];
				specialAttack2 = dragon2Details[2];
				block2 = dragon2Details[3];

			}

			// checking which player will start
			if (frmDargon_Menu.take_Initiative() == 1)
			{   // if Player 1 wins the dice roll.
				groboxAttacker.Text = dragonname1 + "," + dragontype1 + "'s " + " Turn";
				groboxOpponent.Text = "Opponent: " + player2;
				this.Text = player1 + "'s" + " Turn";
				lblAttackerHPScore.Text = "HP: " + dragonHP1.ToString();
				lblOpponentDetails_HPScore.Text = dragonname2 + "," + dragontype2 + "\n HP:" + dragonHP2.ToString();
				playerTurn = true;
				redtBattleOutput.Text = "*****************************************\n" + player1 + "'s dragon " + dragonname1 + " takes initiative!" + "\n*****************************************\n";
			}
			else
			{   // if Player 2 wins the dice roll.
				groboxAttacker.Text = dragonname2 + "," + dragontype2 + "'s " + " Turn";
				groboxOpponent.Text = "Opponent: " + player1;
				this.Text = player2 + "'s" + " Turn";
				lblAttackerHPScore.Text = "HP: " + dragonHP2.ToString();
				lblOpponentDetails_HPScore.Text = dragonname1 + "," + dragontype1 + "\n HP:" + dragonHP1.ToString();
				playerTurn = false;
				redtBattleOutput.Text = "*****************************************\n" + player2 + "'s dragon " + dragonname2 + " takes initiative!" + "\n*****************************************\n";
			}
		}
		private void switchPlayer() //  Once a player has selected a button ( Attack / Block / Speacial Attack).
		{
			if (playerTurn == true)
			{   // Player 2's turn.
				groboxAttacker.Text = dragonname2 + "," + dragontype2 + "'s " + " Turn";
				groboxOpponent.Text = "Opponent: " + player1;
				this.Text = player2 + "'s" + " Turn";
				lblAttackerHPScore.Text = "HP: " + dragonHP2.ToString();
				lblOpponentDetails_HPScore.Text = dragonname1 + "," + dragontype1 + "\n HP:" + dragonHP1.ToString();
				playerTurn = false;

				if (block2Actived == true)
				{
					block2Actived = false;
				}
				if (dragonTired == 2)
				{
					btnDragonRest.Visible = true;
					dragonTired = 0;
				}
			}
			else
			{   // Player 1's turn.
				groboxAttacker.Text = dragonname1 + "," + dragontype1 + "'s " + " Turn";
				groboxOpponent.Text = "Opponent: " + player2;
				this.Text = player1 + "'s" + " Turn";
				lblAttackerHPScore.Text = "HP: " + dragonHP1.ToString();
				lblOpponentDetails_HPScore.Text = dragonname2 + "," + dragontype2 + "\n HP:" + dragonHP2.ToString();
				playerTurn = true;

				if (block1Actived == true)
				{
					block1Actived = false;
				}
				if (dragonTired == 1)
				{
					btnDragonRest.Visible = true;
					dragonTired = 0;
				}
			}
		}
		private void dragonHPZero()
		{// if a dragons HP hits ZERO then this method will be activtated.
			if ((dragonHP1 > 0) & (dragonHP2 > 0))
			{
				btnAttack.Enabled = true;
				btnBlock.Enabled = true;
				btnSpecialAttack.Enabled = true;
			}
			else
			{
				if (dragonHP1 <= 0)
				{
					battleLog(player1 + " is unable to continue." + player2 + " is the victor!!", player2);
				}
				else
				{
					battleLog(player2 + " is unable to continue." + player1 + " is the victor!!", player1);
				}
				btnAttack.Enabled = false;
				btnBlock.Enabled = false;
				btnSpecialAttack.Enabled = false;

			}

		}
		private void blockFlag()
		{// The method for the block button.
			if (playerTurn == true)
			{
				block1Actived = true;
				battleLog(dragonname1 + " has initiated a block\n", player1);
				turnTaken1 = true;

			}
			else
			{
				block2Actived = true;
				battleLog(dragonname2 + " has initiated a block\n", player2);
				turnTaken2 = true;
			}

		}
		private void attackFlag()
		{// The method for the attack button.

			if (playerTurn == true)
			{
				int damageTaken = 0;
				if (block2Actived == false)
				{

					damageTaken = dragonHP2 - Math.Abs(dragonHP2 - attack1);
					dragonHP2 -= damageTaken;
					battleLog(dragonname1 + " attacks " + dragonname2 + "! " + dragonname2 + " takes " + damageTaken.ToString() + " damage and is now on " + dragonHP2.ToString() + " HP ", player1);
				}
				else
				{

					damageTaken = dragonHP2 - (dragonHP2 - Math.Abs(attack1 - block2));
					dragonHP2 -= damageTaken;
					battleLog(dragonname1 + " attacks " + dragonname2 + "! " + dragonname2 + " takes " + damageTaken.ToString() + " damage and is now on " + dragonHP2.ToString() + " HP ", player1);
					block2Actived = false;
				}
				if (dragonHP2 < 0)
				{
					dragonHP2 = 0;
				}
				lblOpponentDetails_HPScore.Text = dragonHP1.ToString();
				turnTaken1 = true;
			}
			else
			{
				int damageTaken = 0;
				if (block1Actived == false)
				{

					damageTaken = dragonHP1 - Math.Abs(dragonHP1 - attack2);
					dragonHP1 -= damageTaken;
					battleLog(dragonname2 + " attacks " + dragonname1 + "! " + dragonname1 + " takes " + damageTaken.ToString() + " damage and is now on " + dragonHP1.ToString() + " HP ", player2);
				}
				else
				{
					damageTaken = dragonHP1 - Math.Abs(dragonHP1 - (attack2 - block1));
					dragonHP1 -= damageTaken;
					battleLog(dragonname2 + " attacks " + dragonname1 + "! " + dragonname1 + " takes " + damageTaken.ToString() + " damage and is now on " + dragonHP1.ToString() + " HP ", player2);
					block1Actived = false;
				}
				if (dragonHP1 < 0)
				{
					dragonHP1 = 0;
				}
				lblOpponentDetails_HPScore.Text = dragonHP2.ToString();
				turnTaken2 = true;
			}

		}
		private void specialAttackFlag()
		{ // The method for the special attack button.

			if (playerTurn == true)
			{

				int damageTaken = 0;
				if (block2Actived == false)
				{

					damageTaken = dragonHP2 - Math.Abs(dragonHP2 - specialAttack1);
					dragonHP2 -= damageTaken;
					battleLog(dragonname1 + " uses a special attack on " + dragonname2 + "! " + dragonname2 + " takes " + damageTaken.ToString() + " damage and is now on " + dragonHP2.ToString() + " HP ", player1);
				}
				else
				{

					damageTaken = dragonHP2 - (dragonHP2 - Math.Abs(specialAttack1 - block2));
					dragonHP2 -= damageTaken;
					battleLog(dragonname1 + " uses a special attack on " + dragonname2 + "! " + dragonname2 + " takes " + damageTaken.ToString() + " damage and is now on " + dragonHP2.ToString() + " HP ", player1);
					block2Actived = false;

				}

				if (dragonHP2 < 0)
				{
					dragonHP2 = 0;
					if (dragonHP2 >= 0)
					{
						btnDragonRest.Visible = false;
					}
				}
				lblOpponentDetails_HPScore.Text = dragonHP1.ToString();
				turnTaken1 = true;
			}
			else
			{

				int damageTaken = 0;
				if (block1Actived == false)
				{

					damageTaken = dragonHP1 - Math.Abs(dragonHP1 - specialAttack2);
					dragonHP1 -= damageTaken;
					battleLog(dragonname2 + " uses a special attack on " + dragonname1 + "! " + dragonname1 + " takes " + damageTaken.ToString() + " damage and is now on " + dragonHP1.ToString() + " HP ", player2);
				}
				else
				{
					damageTaken = dragonHP1 - (dragonHP1 - Math.Abs(specialAttack2 - block1));
					dragonHP1 -= damageTaken;
					battleLog(dragonname2 + " uses a special attack on " + dragonname1 + "! " + dragonname1 + " takes " + damageTaken.ToString() + " damage and is now on " + dragonHP1.ToString() + " HP ", player2);
					block1Actived = false;

				}

				if (dragonHP1 < 0)
				{
					dragonHP1 = 0;
					if (dragonHP1 >= 0)
					{
						btnDragonRest.Visible = false;
					}
				}
				lblOpponentDetails_HPScore.Text = dragonHP2.ToString();
				turnTaken2 = true;
			}


		}
		private void battleLog(string eventText, string name)
		{   // Out put medthod to display what the players are doing. 

			if (turnTaken1 == true & turnTaken2 == true)
			{
				redtBattleOutput.Text += "*************************************************" + "\n" + name + eventText + "\n*************************************************";
			}
			else
			{
				redtBattleOutput.Text += "\n" + "*************************************************" + "\n" + name + "'s turn:\n" + eventText;
			}
		}
		private void rest()
		{ // if a player is attacked with a special attack thier dragon will need to rest and the next player will play. 

			if (playerTurn == false)
			{
				battleLog(dragonname2 + "  is too tired to fight, and needs rest for a while ", player2);
				dragonTired = 2;
			}
			if (playerTurn == true)
			{
				battleLog(dragonname1 + "  is too tired to fight, and needs rest for a while ", player1);
				dragonTired = 1;
			}

		}
		private void nextRound()
		{
			if (turnTaken1 == true & turnTaken2 == true)
			{
				frmDargon_Menu.Random_roll();
				if (frmDargon_Menu.take_Initiative() == 1)
				{   // if Player 1 wins the dice roll.
					groboxAttacker.Text = dragonname1 + "," + dragontype1 + "'s " + " Turn";
					groboxOpponent.Text = "Opponent: " + player2;
					this.Text = player1 + "'s" + " Turn";
					lblAttackerHPScore.Text = "HP: " + dragonHP1.ToString();
					lblOpponentDetails_HPScore.Text = dragonname2 + "," + dragontype2 + "\n HP:" + dragonHP2.ToString();
					playerTurn = true;
					battleLog(dragonname1 + " takes initiative!", player1 + "'s dragon ");
				}
				else
				{   // if Player 2 wins the dice roll.
					groboxAttacker.Text = dragonname2 + "," + dragontype2 + "'s " + " Turn";
					groboxOpponent.Text = "Opponent: " + player1;
					this.Text = player2 + "'s" + " Turn";
					lblAttackerHPScore.Text = "HP: " + dragonHP2.ToString();
					lblOpponentDetails_HPScore.Text = dragonname1 + "," + dragontype1 + "\n HP:" + dragonHP1.ToString();
					playerTurn = false;
					battleLog(dragonname2 + " takes initiative!", player2 + "'s dragon ");
				}
				turnTaken1 = false;
				turnTaken2 = false;
			}
		}

		private void btnAttack_Click(object sender, EventArgs e)
		{
			// Attack condition.
			attackFlag();
			// if Any player's dragon hits zero.
			dragonHPZero();
			// Once a player has played.
			switchPlayer();
			nextRound();
		}

		private void btnSpecialAttack_Click(object sender, EventArgs e)
		{
			// Special attack condition.
			specialAttackFlag();
			// if Any player's dragon hits zero.
			dragonHPZero();
			rest();
			// Once a player has played.
			switchPlayer();
			nextRound();
		}

		private void btnBlock_Click(object sender, EventArgs e)
		{
			// Block condition.
			blockFlag();
			// if Any player's dragon hits zero.
			dragonHPZero();
			// Once a player has played.
			switchPlayer();
			nextRound();
		}

		private void btnDragonRest_Click(object sender, EventArgs e)
		{
			switchPlayer();
			btnDragonRest.Visible = false;
		}
	}
}
