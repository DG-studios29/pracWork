﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dhillan_Gopal_GADE5111_Assignment_1
{
	public partial class frmDargon_Menu : Form
	{
		const string FIRE_DRAG_TYPE = "Fire Dragon";  //{
		const int FIRE_DRAG_HP = 20;
		const int FIRE_DRAG_AD = 5;
		const int FIRE_DRAG_SA = 12;
		const int FIRE_DRAG_BD = 4;

		const string ICE_DRAG_TYPE = "Ice Dragon";
		const int ICE_DRAG_HP = 30;
		const int ICE_DRAG_AD = 4;
		const int ICE_DRAG_SA = 9;
		const int ICE_DRAG_BD = 5;

		const string WIND_DRAG_TYPE = "Wind Dragon";            // Assigning the const vaules for each type dragon.
		const int WIND_DRAG_HP = 40;
		const int WIND_DRAG_AD = 3;
		const int WIND_DRAG_SA = 7;
		const int WIND_DRAG_BD = 5;

		const string EARTH_DRAG_TYPE = "Earth Dragon";
		const int EARTH_DRAG_HP = 50;
		const int EARTH_DRAG_AD = 2;
		const int EARTH_DRAG_SA = 5;
		const int EARTH_DRAG_BD = 6;            //}
		public static int player1;
		public static int player2;
		bool saveOne;
		bool saveTwo;
		// The player 1 array.
		public static string[] player1Information = new string[3];
		// The player 2 array.
		public static string[] player2Information = new string[3];
		// The player 1 dargon stats array.
		public static int[] dragon1Infomation = new int[4];
		// The player 2 dargon stats array.
		public static int[] dragon2Infomation = new int[4];
		public static Random roll = new Random();
		public frmDargon_Menu()
		{
			InitializeComponent();
			btnGameStart.Enabled = false;
		}
		public static int Random_roll()
		{  // Creating random roll.
			return roll.Next(1, 7);
		}
		public static int take_Initiative()
		{
			player1 = Random_roll();
			player2 = Random_roll();
			// Checking which player rolls higher.
			while (player1 == player2)
			{
				player1 = Random_roll();
				player2 = Random_roll();
			}
			if (player1 > player2)
			{
				return 1;

			}
			else
			{
				return 2;
			}
		}
		private void save_Vaules()
		{
				string player1Name;
				string player1Dragon;
				string player2Name;
				string player2Dragon;
				player1Name = edtPlayer1Name.Text;
				// saving the player 1 name. "Astrid"	
				player1Dragon = edtPlayer1Dragon.Text;
				//saving the player 1 dragon name. "Stormfly"
				player2Name = edtPlayer2Name.Text;
				// Saving player 2 name."Hiccup"
				player2Dragon = edtPlayer2Dragon.Text;
				// Saving player 2 dragon name. "Toothless"

				player1Information[0] = player1Name;
				player1Information[1] = player1Dragon;

				// if the dragon type is checked add the stats to Dragon1infomation. (Player 1)
				if (rbtnPlayer1Fire.Checked)
				{  // Assigning the fire dargons stats.
					dragon1Infomation[0] = FIRE_DRAG_HP;
					dragon1Infomation[1] = FIRE_DRAG_AD;
					dragon1Infomation[2] = FIRE_DRAG_SA;
					dragon1Infomation[3] = FIRE_DRAG_BD;
					player1Information[2] = FIRE_DRAG_TYPE;
				}
				if (rbtnPlayer1Ice.Checked)
				{ // Assigning the ice dargons stats.
					dragon1Infomation[0] = ICE_DRAG_HP;
					dragon1Infomation[1] = ICE_DRAG_AD;
					dragon1Infomation[2] = ICE_DRAG_SA;
					dragon1Infomation[3] = ICE_DRAG_BD;
					player1Information[2] = ICE_DRAG_TYPE;
				}
				if (rbtnPlayer1Wind.Checked)
				{   // Assigning the wind dargons stats.
					dragon1Infomation[0] = WIND_DRAG_HP;
					dragon1Infomation[1] = WIND_DRAG_AD;
					dragon1Infomation[2] = WIND_DRAG_SA;
					dragon1Infomation[3] = WIND_DRAG_BD;
					player1Information[2] = WIND_DRAG_TYPE;
				}
				if (rbtnPlayer1Earth.Checked)
				{// Assigning the earth dargons stats.
					dragon1Infomation[0] = EARTH_DRAG_HP;
					dragon1Infomation[1] = EARTH_DRAG_AD;
					dragon1Infomation[2] = EARTH_DRAG_SA;
					dragon1Infomation[3] = EARTH_DRAG_BD;
					player1Information[2] = EARTH_DRAG_TYPE;
				}

				player2Information[0] = player2Name;
				player2Information[1] = player2Dragon;
				// if the dragon type is checked add the stats to Dragon1infomation. (Player 2)
				if (rbtnPlayer2Fire.Checked)
				{// Assigning the fire dargons stats.
					dragon2Infomation[0] = FIRE_DRAG_HP;
					dragon2Infomation[1] = FIRE_DRAG_AD;
					dragon2Infomation[2] = FIRE_DRAG_SA;
					dragon2Infomation[3] = FIRE_DRAG_BD;
					player2Information[2] = FIRE_DRAG_TYPE;
				}
				if (rbtnPlayer2Ice.Checked)
				{// Assigning the ice dargons stats.
					dragon2Infomation[0] = ICE_DRAG_HP;
					dragon2Infomation[1] = ICE_DRAG_AD;
					dragon2Infomation[2] = ICE_DRAG_SA;
					dragon2Infomation[3] = ICE_DRAG_BD;
					player2Information[2] = ICE_DRAG_TYPE;
				}
				if (rbtnPlayer2Wind.Checked)
				{ // Assigning the wind dargons stats.
					dragon2Infomation[0] = WIND_DRAG_HP;
					dragon2Infomation[1] = WIND_DRAG_AD;
					dragon2Infomation[2] = WIND_DRAG_SA;
					dragon2Infomation[3] = WIND_DRAG_BD;
					player2Information[2] = WIND_DRAG_TYPE;
				}
				if (rbtnPlayer2Earth.Checked)
				{  // Assigning the earth dargons stats.
					dragon2Infomation[0] = EARTH_DRAG_HP;
					dragon2Infomation[1] = EARTH_DRAG_AD;
					dragon2Infomation[2] = EARTH_DRAG_SA;
					dragon2Infomation[3] = EARTH_DRAG_BD;
					player2Information[2] = EARTH_DRAG_TYPE;
				}


		}
		private void buttonSaveCheck()
		{  // This method is to check that the two save buttons have been clicked.
			if (saveOne == true & saveTwo == true)
			{  // enables the user to move ro the next form.
				btnGameStart.Enabled = true;
			}
		}
		private void nextForm()
		{
			FrmDragonBattle next = new FrmDragonBattle();
			next.Show();
			this.Hide();
		}

		private void btnPlayer1Save_Click(object sender, EventArgs e)
		{
			saveOne = true;                                                 // In order for the button check method to work(method: buttonSaveCheck).
			save_Vaules();                                                  // Adds the vaules for the user to the arrays.
			btnPlayer1Save.ForeColor = Color.DarkGreen;                     // This colour change indicates that the button has been clicked.
			buttonSaveCheck();
		}

		private void btnPlayer2Save_Click(object sender, EventArgs e)
		{
			saveTwo = true;                                         // In order for the button check method to work(method: buttonSaveCheck).
			save_Vaules();                                           // Adds the vaules for the user to the arrays.
			btnPlayer2Save.ForeColor = Color.DarkGreen;             // This colour change indicates that the button has been clicked.
			buttonSaveCheck();
		}

		private void btnGameStart_Click(object sender, EventArgs e)
		{
			nextForm();
			take_Initiative();
		}
		public static void onLoad()
		{
			FrmDragonBattle.player1Details[0] = player1Information[0];
			FrmDragonBattle.player1Details[1] = player1Information[1];
			FrmDragonBattle.player1Details[2] = player1Information[2];
			FrmDragonBattle.player2Details[0] = player2Information[0];
			FrmDragonBattle.player2Details[1] = player2Information[1];
			FrmDragonBattle.player2Details[2] = player2Information[2];
			FrmDragonBattle.dragon1Details[0] = dragon1Infomation[0];
			FrmDragonBattle.dragon1Details[1] = dragon1Infomation[1];
			FrmDragonBattle.dragon1Details[2] = dragon1Infomation[2];
			FrmDragonBattle.dragon1Details[3] = dragon1Infomation[3];
			FrmDragonBattle.dragon2Details[0] = dragon2Infomation[0];
			FrmDragonBattle.dragon2Details[1] = dragon2Infomation[1];
			FrmDragonBattle.dragon2Details[2] = dragon2Infomation[2];
			FrmDragonBattle.dragon2Details[1] = dragon2Infomation[3];

		}
	}
}
