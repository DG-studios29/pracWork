﻿namespace Dhillan_Gopal_GADE5111_Assignment_1
{
	partial class FrmDragonBattle
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDragonBattle));
			this.groboxAttacker = new System.Windows.Forms.GroupBox();
			this.btnDragonRest = new System.Windows.Forms.Button();
			this.lblAttackerHPScore = new System.Windows.Forms.Label();
			this.btnBlock = new System.Windows.Forms.Button();
			this.btnSpecialAttack = new System.Windows.Forms.Button();
			this.btnAttack = new System.Windows.Forms.Button();
			this.groboxOpponent = new System.Windows.Forms.GroupBox();
			this.lblOpponentDetails_HPScore = new System.Windows.Forms.Label();
			this.groboxBattleLog = new System.Windows.Forms.GroupBox();
			this.redtBattleOutput = new System.Windows.Forms.RichTextBox();
			this.groboxAttacker.SuspendLayout();
			this.groboxOpponent.SuspendLayout();
			this.groboxBattleLog.SuspendLayout();
			this.SuspendLayout();
			// 
			// groboxAttacker
			// 
			this.groboxAttacker.BackColor = System.Drawing.Color.Transparent;
			this.groboxAttacker.Controls.Add(this.btnDragonRest);
			this.groboxAttacker.Controls.Add(this.lblAttackerHPScore);
			this.groboxAttacker.Controls.Add(this.btnBlock);
			this.groboxAttacker.Controls.Add(this.btnSpecialAttack);
			this.groboxAttacker.Controls.Add(this.btnAttack);
			this.groboxAttacker.ForeColor = System.Drawing.Color.Aqua;
			this.groboxAttacker.Location = new System.Drawing.Point(12, 12);
			this.groboxAttacker.Name = "groboxAttacker";
			this.groboxAttacker.Size = new System.Drawing.Size(260, 290);
			this.groboxAttacker.TabIndex = 0;
			this.groboxAttacker.TabStop = false;
			// 
			// btnDragonRest
			// 
			this.btnDragonRest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btnDragonRest.ForeColor = System.Drawing.Color.DarkGreen;
			this.btnDragonRest.Location = new System.Drawing.Point(6, 103);
			this.btnDragonRest.Name = "btnDragonRest";
			this.btnDragonRest.Size = new System.Drawing.Size(248, 180);
			this.btnDragonRest.TabIndex = 2;
			this.btnDragonRest.Text = "Rest";
			this.btnDragonRest.UseVisualStyleBackColor = true;
			this.btnDragonRest.Visible = false;
			this.btnDragonRest.Click += new System.EventHandler(this.btnDragonRest_Click);
			// 
			// lblAttackerHPScore
			// 
			this.lblAttackerHPScore.AutoSize = true;
			this.lblAttackerHPScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblAttackerHPScore.Location = new System.Drawing.Point(44, 51);
			this.lblAttackerHPScore.Name = "lblAttackerHPScore";
			this.lblAttackerHPScore.Size = new System.Drawing.Size(0, 32);
			this.lblAttackerHPScore.TabIndex = 2;
			// 
			// btnBlock
			// 
			this.btnBlock.ForeColor = System.Drawing.Color.Blue;
			this.btnBlock.Location = new System.Drawing.Point(6, 228);
			this.btnBlock.Name = "btnBlock";
			this.btnBlock.Size = new System.Drawing.Size(248, 56);
			this.btnBlock.TabIndex = 1;
			this.btnBlock.Text = "Block";
			this.btnBlock.UseVisualStyleBackColor = true;
			this.btnBlock.Click += new System.EventHandler(this.btnBlock_Click);
			// 
			// btnSpecialAttack
			// 
			this.btnSpecialAttack.ForeColor = System.Drawing.Color.Red;
			this.btnSpecialAttack.Location = new System.Drawing.Point(6, 166);
			this.btnSpecialAttack.Name = "btnSpecialAttack";
			this.btnSpecialAttack.Size = new System.Drawing.Size(248, 56);
			this.btnSpecialAttack.TabIndex = 1;
			this.btnSpecialAttack.Text = "Special Attack";
			this.btnSpecialAttack.UseVisualStyleBackColor = true;
			this.btnSpecialAttack.Click += new System.EventHandler(this.btnSpecialAttack_Click);
			// 
			// btnAttack
			// 
			this.btnAttack.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
			this.btnAttack.Location = new System.Drawing.Point(6, 104);
			this.btnAttack.Name = "btnAttack";
			this.btnAttack.Size = new System.Drawing.Size(248, 56);
			this.btnAttack.TabIndex = 1;
			this.btnAttack.Text = "Attack";
			this.btnAttack.UseVisualStyleBackColor = true;
			this.btnAttack.Click += new System.EventHandler(this.btnAttack_Click);
			// 
			// groboxOpponent
			// 
			this.groboxOpponent.BackColor = System.Drawing.Color.Transparent;
			this.groboxOpponent.Controls.Add(this.lblOpponentDetails_HPScore);
			this.groboxOpponent.ForeColor = System.Drawing.Color.Aqua;
			this.groboxOpponent.Location = new System.Drawing.Point(340, 116);
			this.groboxOpponent.Name = "groboxOpponent";
			this.groboxOpponent.Size = new System.Drawing.Size(300, 118);
			this.groboxOpponent.TabIndex = 0;
			this.groboxOpponent.TabStop = false;
			// 
			// lblOpponentDetails_HPScore
			// 
			this.lblOpponentDetails_HPScore.AutoSize = true;
			this.lblOpponentDetails_HPScore.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblOpponentDetails_HPScore.Location = new System.Drawing.Point(34, 44);
			this.lblOpponentDetails_HPScore.Name = "lblOpponentDetails_HPScore";
			this.lblOpponentDetails_HPScore.Size = new System.Drawing.Size(0, 25);
			this.lblOpponentDetails_HPScore.TabIndex = 0;
			// 
			// groboxBattleLog
			// 
			this.groboxBattleLog.BackColor = System.Drawing.Color.Transparent;
			this.groboxBattleLog.Controls.Add(this.redtBattleOutput);
			this.groboxBattleLog.ForeColor = System.Drawing.Color.Aqua;
			this.groboxBattleLog.Location = new System.Drawing.Point(12, 317);
			this.groboxBattleLog.Name = "groboxBattleLog";
			this.groboxBattleLog.Size = new System.Drawing.Size(628, 225);
			this.groboxBattleLog.TabIndex = 1;
			this.groboxBattleLog.TabStop = false;
			this.groboxBattleLog.Text = "Battle Log";
			// 
			// redtBattleOutput
			// 
			this.redtBattleOutput.Location = new System.Drawing.Point(6, 21);
			this.redtBattleOutput.Name = "redtBattleOutput";
			this.redtBattleOutput.Size = new System.Drawing.Size(616, 198);
			this.redtBattleOutput.TabIndex = 0;
			this.redtBattleOutput.Text = "";
			// 
			// FrmDragonBattle
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
			this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
			this.ClientSize = new System.Drawing.Size(667, 565);
			this.Controls.Add(this.groboxBattleLog);
			this.Controls.Add(this.groboxOpponent);
			this.Controls.Add(this.groboxAttacker);
			this.Name = "FrmDragonBattle";
			this.groboxAttacker.ResumeLayout(false);
			this.groboxAttacker.PerformLayout();
			this.groboxOpponent.ResumeLayout(false);
			this.groboxOpponent.PerformLayout();
			this.groboxBattleLog.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.GroupBox groboxAttacker;
		private System.Windows.Forms.Button btnBlock;
		private System.Windows.Forms.Button btnSpecialAttack;
		private System.Windows.Forms.Button btnAttack;
		private System.Windows.Forms.GroupBox groboxOpponent;
		private System.Windows.Forms.Label lblAttackerHPScore;
		private System.Windows.Forms.Label lblOpponentDetails_HPScore;
		private System.Windows.Forms.GroupBox groboxBattleLog;
		private System.Windows.Forms.RichTextBox redtBattleOutput;
		private System.Windows.Forms.Button btnDragonRest;
	}
}