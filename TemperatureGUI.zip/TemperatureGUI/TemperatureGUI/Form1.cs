﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TemperatureGUI
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			float iTemp = Convert.ToInt32(edtTemp.Text);

			if (iTemp > 23)
				lblTempDisply.Text = "Temperature is:  Warm";
			if (iTemp >= 18 && iTemp <= 22.9)
				lblTempDisply.Text = "Temperature is: Moderate";
			if (iTemp < 18)
				lblTempDisply.Text = "Temperature is: Cold";







		}
	}
}
